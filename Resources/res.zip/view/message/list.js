// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(249)
	)
	__vue_styles__.push(__webpack_require__(250)
	)

	/* script */
	__vue_exports__ = __webpack_require__(251)

	/* template */
	var __vue_template__ = __webpack_require__(252)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/message/list.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-21e5de8e"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 249:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 28,
	    "color": "#bbbbbb"
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#bbbbbb",
	    "backgroundColor": "#D9141E"
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#bbbbbb",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderBottomWidth": 0,
	    "borderTopWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#D9141E"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#D9141E"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#D9141E"
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#D9141E"
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#D9141E"
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "backgroundColor": "#D9141E",
	    "borderRadius": 15,
	    "backgroundColor:active": "#bbbbbb",
	    "color:active": "#D9141E",
	    "backgroundColor:disabled": "#D9141E",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#D9141E",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 250:
/***/ (function(module, exports) {

	module.exports = {
	  "nav": {
	    "flex": 1,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "justifyContent": "center",
	    "marginTop": 40
	  },
	  "menu": {
	    "marginTop": 40,
	    "fontSize": 50,
	    "lineHeight": 60,
	    "height": 60,
	    "width": 60,
	    "color": "#FFFFFF"
	  },
	  "messageTotal": {
	    "backgroundColor": "#FF0000",
	    "lineHeight": 38,
	    "lines": 1,
	    "color": "#ffffff",
	    "width": 38,
	    "height": 38,
	    "textAlign": "center",
	    "borderRadius": 19,
	    "fontSize": 20,
	    "fontWeight": "700"
	  },
	  "newMessage": {
	    "position": "absolute",
	    "left": 95,
	    "top": 5,
	    "width": 60,
	    "alignItems": "center"
	  },
	  "messageTimeBox": {
	    "paddingTop": 8,
	    "flex": 1,
	    "alignItems": "flex-end",
	    "paddingRight": 10
	  },
	  "messageTime": {
	    "color": "#999999",
	    "fontSize": 24,
	    "lines": 1
	  },
	  "friendName": {
	    "lines": 1,
	    "textOverflow": "ellipsis",
	    "fontSize": 34
	  },
	  "messageText": {
	    "paddingTop": 8,
	    "paddingBottom": 8,
	    "flex": 5,
	    "height": 100,
	    "justifyContent": "space-between",
	    "marginLeft": 20
	  },
	  "friendMessage": {
	    "lines": 1,
	    "textOverflow": "ellipsis",
	    "color": "#999999",
	    "fontSize": 28
	  },
	  "friendsImageBox": {
	    "flex": 1
	  },
	  "friendsImage": {
	    "height": 100,
	    "width": 100
	  },
	  "friendsLine": {
	    "paddingLeft": 30,
	    "paddingRight": 20,
	    "paddingTop": 15,
	    "paddingBottom": 15,
	    "width": 750,
	    "backgroundColor": "#ffffff",
	    "flexDirection": "row",
	    "borderBottomWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "rgba(153,153,153,0.2)"
	  }
	}

/***/ }),

/***/ 251:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var modal = weex.requireModule('modal');
	var dom = weex.requireModule("dom");
	exports.default = {
	    data: function data() {
	        return {

	            refreshing: false,
	            messageList: [{
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '信徒',
	                friendMessage: '怎么不回消息？',
	                messageTime: '10:07',
	                messageTotal: 99
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '霍建华',
	                friendMessage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXX',
	                messageTime: '11:08',
	                messageTotal: 17
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '胡歌',
	                friendMessage: '胡歌邀请你参加《琅琊榜2》的录制,点击链接即可报名！',
	                messageTime: '12:09',
	                messageTotal: 1
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: 'Famous、库',
	                friendMessage: '哈哈哈，好无聊',
	                messageTime: '昨天',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '陈小春',
	                friendMessage: '',
	                messageTime: '12:07',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '番茄',
	                friendMessage: '炒蛋吗？',
	                messageTime: '9月8日',
	                messageTotal: '1'
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '豪客来',
	                friendMessage: '秋天，又到了吃货的季节。快上库鲁子网挑选吧！',
	                messageTime: '9月8日',
	                messageTotal: '1'
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '中国有嘻哈',
	                friendMessage: '你会freestyle吗？',
	                messageTime: '昨天',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '那英',
	                friendMessage: '！',
	                messageTime: '昨天',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '中国新歌声',
	                friendMessage: '',
	                messageTime: '昨天',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '陈小春',
	                friendMessage: '',
	                messageTime: '12:07',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '番茄',
	                friendMessage: '炒蛋吗？',
	                messageTime: '9月8日',
	                messageTotal: '1'
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '豪客来',
	                friendMessage: '秋天，又到了吃货的季节。快上库鲁子网挑选吧！',
	                messageTime: '9月8日',
	                messageTotal: '1'
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '中国有嘻哈',
	                friendMessage: '你会freestyle吗？',
	                messageTime: '昨天',
	                messageTotal: ''
	            }, {
	                friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                friendName: '那英',
	                friendMessage: '！',
	                messageTime: '昨天',
	                messageTotal: ''
	            }]
	        };
	    },
	    created: function created() {
	        var _this = this;
	        dom.addRule('fontFace', {
	            'fontFamily': 'iconfont',
	            'src': "url('" + _this.locateURL + "/resources/fonts/iconfont.ttf')"
	        });
	    },

	    methods: {
	        //            下拉刷新
	        onrefresh: function onrefresh(event) {
	            var _this2 = this;

	            modal.toast({ message: '加载中...', duration: 1 });
	            this.refreshing = true;
	            setTimeout(function () {
	                _this2.refreshing = false;
	            }, 2000);
	        },

	        jump: function jump(page) {},
	        menu: function menu(page) {}
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 252:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["wrapper"]
	  }, [_c('div', {
	    staticClass: ["header"]
	  }, [_c('div', {
	    staticClass: ["flex-center", "flex1"]
	  }), _vm._m(0), _c('div', {
	    staticClass: ["flex-center", "flex1"],
	    on: {
	      "click": function($event) {
	        _vm.menu()
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["menu"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])])]), _c('list', {
	    staticClass: ["list"]
	  }, [_c('refresh', {
	    staticClass: ["refresh"],
	    attrs: {
	      "display": _vm.refreshing ? 'show' : 'hide'
	    },
	    on: {
	      "refresh": _vm.onrefresh
	    }
	  }, [_c('text', {
	    staticClass: ["indicator"]
	  }, [_vm._v("下拉刷新 ...")])]), _vm._l((_vm.messageList), function(item) {
	    return _c('cell', {
	      appendAsTree: true,
	      attrs: {
	        "append": "tree"
	      }
	    }, [_c('div', {
	      staticClass: ["friendsLine"],
	      on: {
	        "click": function($event) {
	          _vm.jump('/member')
	        }
	      }
	    }, [_c('div', {
	      staticClass: ["friendsImageBox"]
	    }, [_c('image', {
	      staticClass: ["friendsImage"],
	      attrs: {
	        "src": item.friendImage
	      }
	    })]), (item.messageTotal != '') ? _c('div', {
	      staticClass: ["newMessage"]
	    }, [_c('text', {
	      staticClass: ["messageTotal"]
	    }, [_vm._v(_vm._s(item.messageTotal))])]) : _vm._e(), _c('div', {
	      staticClass: ["messageText"]
	    }, [_c('text', {
	      staticClass: ["friendName"]
	    }, [_vm._v(_vm._s(item.friendName))]), _c('text', {
	      staticClass: ["friendMessage"]
	    }, [_vm._v(_vm._s(item.friendMessage))])]), _c('div', {
	      staticClass: ["messageTimeBox"]
	    }, [_c('text', {
	      staticClass: ["messageTime"]
	    }, [_vm._v(_vm._s(item.messageTime))])])])])
	  })], 2)])
	},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["nav", "flex4"]
	  }, [_c('text', {
	    staticClass: ["nav_title"]
	  }, [_vm._v("消息")])])
	}]}
	module.exports.render._withStripped = true

/***/ })

/******/ });