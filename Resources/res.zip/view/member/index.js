// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(198)
	)

	/* script */
	__vue_exports__ = __webpack_require__(199)

	/* template */
	var __vue_template__ = __webpack_require__(204)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/member/index.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-4434fa85"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

	var global = __webpack_require__(11);
	var core = __webpack_require__(12);
	var ctx = __webpack_require__(13);
	var hide = __webpack_require__(15);
	var PROTOTYPE = 'prototype';

	var $export = function (type, name, source) {
	  var IS_FORCED = type & $export.F;
	  var IS_GLOBAL = type & $export.G;
	  var IS_STATIC = type & $export.S;
	  var IS_PROTO = type & $export.P;
	  var IS_BIND = type & $export.B;
	  var IS_WRAP = type & $export.W;
	  var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
	  var expProto = exports[PROTOTYPE];
	  var target = IS_GLOBAL ? global : IS_STATIC ? global[name] : (global[name] || {})[PROTOTYPE];
	  var key, own, out;
	  if (IS_GLOBAL) source = name;
	  for (key in source) {
	    // contains in native
	    own = !IS_FORCED && target && target[key] !== undefined;
	    if (own && key in exports) continue;
	    // export native or passed
	    out = own ? target[key] : source[key];
	    // prevent global pollution for namespaces
	    exports[key] = IS_GLOBAL && typeof target[key] != 'function' ? source[key]
	    // bind timers to global for call from export context
	    : IS_BIND && own ? ctx(out, global)
	    // wrap global constructors for prevent change them in library
	    : IS_WRAP && target[key] == out ? (function (C) {
	      var F = function (a, b, c) {
	        if (this instanceof C) {
	          switch (arguments.length) {
	            case 0: return new C();
	            case 1: return new C(a);
	            case 2: return new C(a, b);
	          } return new C(a, b, c);
	        } return C.apply(this, arguments);
	      };
	      F[PROTOTYPE] = C[PROTOTYPE];
	      return F;
	    // make static versions for prototype methods
	    })(out) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
	    // export proto methods to core.%CONSTRUCTOR%.methods.%NAME%
	    if (IS_PROTO) {
	      (exports.virtual || (exports.virtual = {}))[key] = out;
	      // export proto methods to core.%CONSTRUCTOR%.prototype.%NAME%
	      if (type & $export.R && expProto && !expProto[key]) hide(expProto, key, out);
	    }
	  }
	};
	// type bitmap
	$export.F = 1;   // forced
	$export.G = 2;   // global
	$export.S = 4;   // static
	$export.P = 8;   // proto
	$export.B = 16;  // bind
	$export.W = 32;  // wrap
	$export.U = 64;  // safe
	$export.R = 128; // real proto method for `library`
	module.exports = $export;


/***/ }),

/***/ 11:
/***/ (function(module, exports) {

	// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
	var global = module.exports = typeof window != 'undefined' && window.Math == Math
	  ? window : typeof self != 'undefined' && self.Math == Math ? self
	  // eslint-disable-next-line no-new-func
	  : Function('return this')();
	if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef


/***/ }),

/***/ 12:
/***/ (function(module, exports) {

	var core = module.exports = { version: '2.5.1' };
	if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef


/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

	// optional / simple context binding
	var aFunction = __webpack_require__(14);
	module.exports = function (fn, that, length) {
	  aFunction(fn);
	  if (that === undefined) return fn;
	  switch (length) {
	    case 1: return function (a) {
	      return fn.call(that, a);
	    };
	    case 2: return function (a, b) {
	      return fn.call(that, a, b);
	    };
	    case 3: return function (a, b, c) {
	      return fn.call(that, a, b, c);
	    };
	  }
	  return function (/* ...args */) {
	    return fn.apply(that, arguments);
	  };
	};


/***/ }),

/***/ 14:
/***/ (function(module, exports) {

	module.exports = function (it) {
	  if (typeof it != 'function') throw TypeError(it + ' is not a function!');
	  return it;
	};


/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

	var dP = __webpack_require__(16);
	var createDesc = __webpack_require__(24);
	module.exports = __webpack_require__(20) ? function (object, key, value) {
	  return dP.f(object, key, createDesc(1, value));
	} : function (object, key, value) {
	  object[key] = value;
	  return object;
	};


/***/ }),

/***/ 16:
/***/ (function(module, exports, __webpack_require__) {

	var anObject = __webpack_require__(17);
	var IE8_DOM_DEFINE = __webpack_require__(19);
	var toPrimitive = __webpack_require__(23);
	var dP = Object.defineProperty;

	exports.f = __webpack_require__(20) ? Object.defineProperty : function defineProperty(O, P, Attributes) {
	  anObject(O);
	  P = toPrimitive(P, true);
	  anObject(Attributes);
	  if (IE8_DOM_DEFINE) try {
	    return dP(O, P, Attributes);
	  } catch (e) { /* empty */ }
	  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
	  if ('value' in Attributes) O[P] = Attributes.value;
	  return O;
	};


/***/ }),

/***/ 17:
/***/ (function(module, exports, __webpack_require__) {

	var isObject = __webpack_require__(18);
	module.exports = function (it) {
	  if (!isObject(it)) throw TypeError(it + ' is not an object!');
	  return it;
	};


/***/ }),

/***/ 18:
/***/ (function(module, exports) {

	module.exports = function (it) {
	  return typeof it === 'object' ? it !== null : typeof it === 'function';
	};


/***/ }),

/***/ 19:
/***/ (function(module, exports, __webpack_require__) {

	module.exports = !__webpack_require__(20) && !__webpack_require__(21)(function () {
	  return Object.defineProperty(__webpack_require__(22)('div'), 'a', { get: function () { return 7; } }).a != 7;
	});


/***/ }),

/***/ 20:
/***/ (function(module, exports, __webpack_require__) {

	// Thank's IE8 for his funny defineProperty
	module.exports = !__webpack_require__(21)(function () {
	  return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
	});


/***/ }),

/***/ 21:
/***/ (function(module, exports) {

	module.exports = function (exec) {
	  try {
	    return !!exec();
	  } catch (e) {
	    return true;
	  }
	};


/***/ }),

/***/ 22:
/***/ (function(module, exports, __webpack_require__) {

	var isObject = __webpack_require__(18);
	var document = __webpack_require__(11).document;
	// typeof document.createElement is 'object' in old IE
	var is = isObject(document) && isObject(document.createElement);
	module.exports = function (it) {
	  return is ? document.createElement(it) : {};
	};


/***/ }),

/***/ 23:
/***/ (function(module, exports, __webpack_require__) {

	// 7.1.1 ToPrimitive(input [, PreferredType])
	var isObject = __webpack_require__(18);
	// instead of the ES6 spec version, we didn't implement @@toPrimitive case
	// and the second argument - flag - preferred type is a string
	module.exports = function (it, S) {
	  if (!isObject(it)) return it;
	  var fn, val;
	  if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
	  if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
	  if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
	  throw TypeError("Can't convert object to primitive value");
	};


/***/ }),

/***/ 24:
/***/ (function(module, exports) {

	module.exports = function (bitmap, value) {
	  return {
	    enumerable: !(bitmap & 1),
	    configurable: !(bitmap & 2),
	    writable: !(bitmap & 4),
	    value: value
	  };
	};


/***/ }),

/***/ 170:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var dom = weex.requireModule('dom');
	var event = weex.requireModule('event');
	var stream = weex.requireModule('stream');
	var storage = weex.requireModule('storage');
	exports.default = { dom: dom, event: event, stream: stream, storage: storage };
	module.exports = exports['default'];

/***/ }),

/***/ 198:
/***/ (function(module, exports) {

	module.exports = {
	  "@TRANSITION": {
	    "paraTransition-enter-active": {
	      "duration": 200
	    },
	    "paraTransition-leave-active": {
	      "duration": 200
	    }
	  },
	  "paraTransition-leave-to": {
	    "transform": "translateX(0px)",
	    "opacity": 0
	  },
	  "paraTransition-enter-to": {
	    "transform": "translateX(0px)",
	    "opacity": 1
	  },
	  "paraTransition-enter": {
	    "transform": "translateX(0px)",
	    "opacity": 0
	  },
	  "rightBlur": {
	    "right": 100,
	    "width": 20,
	    "backgroundImage": "linear-gradient(to left, #F8F9FC,#fff)"
	  },
	  "leftBlur": {
	    "left": 0,
	    "backgroundImage": "linear-gradient(to right, #F8F9FC,#fff)"
	  },
	  "blur": {
	    "position": "absolute",
	    "height": 79,
	    "width": 20,
	    "top": 0,
	    "opacity": 0.9
	  },
	  "corpusBox": {
	    "flexDirection": "row",
	    "backgroundColor": "#F8F9FC",
	    "height": 80,
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#DCDCDC"
	  },
	  "redColor": {
	    "color": "#D9141E"
	  },
	  "rightHiddenIconBox": {
	    "justifyContent": "center",
	    "alignItems": "center"
	  },
	  "rightHiddenSmallBox": {
	    "flexDirection": "row",
	    "flex": 1,
	    "justifyContent": "space-around",
	    "alignItems": "center"
	  },
	  "rightHiddenText": {
	    "fontSize": 24,
	    "color": "#999999"
	  },
	  "rightHiddenIcon": {
	    "textAlign": "center",
	    "lineHeight": 90,
	    "fontSize": 40,
	    "width": 90,
	    "height": 90,
	    "borderRadius": 45,
	    "color": "#000000",
	    "backgroundColor": "#ffffff",
	    "marginBottom": 15
	  },
	  "rightHidden": {
	    "position": "absolute",
	    "right": 0,
	    "top": 0,
	    "backgroundColor": "#f4f4f4",
	    "width": 330,
	    "height": 457
	  },
	  "relevantImage": {
	    "flexDirection": "row",
	    "fontSize": 32,
	    "color": "#888888",
	    "marginRight": 5,
	    "marginLeft": 5,
	    "alignItems": "center"
	  },
	  "relevantText": {
	    "color": "#888888",
	    "fontSize": 26
	  },
	  "relevantInfo": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "articleFoot": {
	    "flexDirection": "row",
	    "justifyContent": "space-between",
	    "width": 710,
	    "alignItems": "center"
	  },
	  "articleDate": {
	    "fontSize": 24,
	    "color": "#888888"
	  },
	  "articleCover": {
	    "height": 300,
	    "width": 710,
	    "borderRadius": 5,
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "articleBox": {
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "paddingTop": 20,
	    "paddingRight": 20,
	    "paddingBottom": 20,
	    "marginBottom": 10,
	    "width": 1080,
	    "display": "inline-block"
	  },
	  "atricleHead": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "articleTitle": {
	    "fontSize": 32,
	    "marginLeft": 10
	  },
	  "articleSign": {
	    "borderRadius": 10,
	    "padding": 5,
	    "color": "#888888",
	    "fontSize": 26,
	    "borderWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#DCDCDC"
	  },
	  "indicator": {
	    "width": 750,
	    "height": 80,
	    "textAlign": "center",
	    "lineHeight": 80
	  },
	  "wrapper": {
	    "backgroundColor": "#f4f4f4"
	  },
	  "tipsText": {
	    "color": "#808080",
	    "fontSize": 26,
	    "marginTop": 240,
	    "paddingBottom": 200
	  },
	  "active": {
	    "color": "#F0AD3C",
	    "borderColor": "#F0AD3C",
	    "borderStyle": "solid",
	    "borderBottomWidth": 4
	  },
	  "noActive": {
	    "borderBottomWidth": 0
	  },
	  "articleClass": {
	    "flexDirection": "row",
	    "paddingLeft": 10,
	    "borderBottomWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#DCDCDC",
	    "height": 80,
	    "position": "sticky",
	    "backgroundColor": "#F8F9FC"
	  },
	  "allArticle": {
	    "fontSize": 29,
	    "lineHeight": 80,
	    "paddingLeft": 20,
	    "paddingRight": 20
	  },
	  "recycleSite": {
	    "fontSize": 29,
	    "lineHeight": 80,
	    "paddingLeft": 20,
	    "paddingRight": 20
	  },
	  "topBtnOne": {
	    "borderColor": "#FFFFFF",
	    "borderRightWidth": 1,
	    "borderStyle": "solid"
	  },
	  "topBtnTwo": {
	    "borderColor": "#FFFFFF",
	    "borderRightWidth": 1,
	    "borderStyle": "solid"
	  },
	  "backgroundImage": {
	    "position": "absolute",
	    "width": 750,
	    "top": 0,
	    "height": 420,
	    "filter": "blur(4px)",
	    "opacity": 0.8
	  },
	  "topBox": {
	    "position": "relative",
	    "paddingTop": 40,
	    "height": 420
	  },
	  "topBtnBox": {
	    "flexDirection": "row",
	    "alignItems": "center",
	    "marginTop": 40,
	    "width": 500,
	    "marginLeft": 125
	  },
	  "topBtnSmallBox": {
	    "height": 80,
	    "flex": 1
	  },
	  "topBtn": {
	    "color": "#FFFFFF",
	    "fontSize": 24,
	    "textAlign": "center",
	    "height": 40,
	    "lineHeight": 40
	  },
	  "topBtnBigFont": {
	    "fontWeight": "600",
	    "fontSize": 32
	  },
	  "topHead": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 20,
	    "color": "#FFFFFF"
	  },
	  "testImage": {
	    "width": 120,
	    "height": 120,
	    "borderRadius": 50
	  },
	  "userSign": {
	    "lines": 1,
	    "textOverflow": "ellipsis",
	    "width": 500,
	    "fontSize": 26,
	    "color": "#FFFFFF"
	  },
	  "userName": {
	    "fontWeight": "600",
	    "fontSize": 32,
	    "marginTop": 15,
	    "marginBottom": 15,
	    "color": "#FFFFFF"
	  }
	}

/***/ }),

/***/ 199:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _defineProperty2 = __webpack_require__(200);

	var _defineProperty3 = _interopRequireDefault(_defineProperty2);

	var _weex = __webpack_require__(170);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var modal = weex.requireModule('modal'); //
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var animation = weex.requireModule('animation');
	var animationPara; //执行动画的文章
	var scrollTop = 0;
	var recycleScroll = 0;
	var allArticleScroll = 0;
	exports.default = {
	    data: function data() {
	        var _ref;

	        return _ref = {
	            canScroll: true,
	            userName: '柯志杰',
	            userSign: '刮风下雨打雷台风天。刮风下雨打雷台风天。刮风下雨打雷台风天。刮风下雨打雷台风天。刮风下雨打雷台风天。刮风下雨打雷台风天。',
	            whichCorpus: '全部文章',
	            isNoArticle: false,
	            refreshing: 'hide',
	            fontName: '&#xe685;',
	            collectNum: 0,
	            moneyNum: 0,
	            focusNum: 0,
	            imageUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            id: '334',
	            showLoading: 'hide'
	        }, (0, _defineProperty3.default)(_ref, 'imageUrl', 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg'), (0, _defineProperty3.default)(_ref, 'memberArticleList', [{
	            corpus: '全部文章',
	            articleList: [{
	                articleSign: '样例',
	                articleTitle: '我在微信有了自己的专栏!',
	                articleCoverUrl: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-04-28',
	                id: '1'
	            }, {
	                articleSign: '样例',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-09-01',
	                id: '2'
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: '3'
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: '4'
	            }]
	        }, {
	            corpus: '回收站',
	            articleList: [{
	                articleSign: '样例',
	                articleTitle: '我在微信有了自己的专栏!',
	                articleCoverUrl: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-04-28',
	                id: '11'
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }, {
	                articleSign: '样例',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }]
	        }, {
	            corpus: '我的第一个文集',
	            articleList: [{
	                articleSign: '样例',
	                articleTitle: '我在微信有了自己的专栏!',
	                articleCoverUrl: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-04-28',
	                id: ''
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }, {
	                articleSign: '样例',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }]
	        }, {
	            corpus: '诚毅学院点滴',
	            articleList: [{
	                articleSign: '公开',
	                articleTitle: '我在微信有了自己的专栏!',
	                articleCoverUrl: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-04-28',
	                id: ''
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }, {
	                articleSign: '私密',
	                articleTitle: '魔篇使用帮助',
	                articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	                articleDate: '2017-09-01',
	                id: ''
	            }]
	        }]), (0, _defineProperty3.default)(_ref, 'helpList', [{
	            articleSign: '样例',
	            articleTitle: '我在微信有了自己的专栏!',
	            articleCoverUrl: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg',
	            articleDate: '2017-04-28',
	            id: ''
	        }, {
	            articleSign: '样例',
	            articleTitle: '魔篇使用帮助',
	            articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	            articleDate: '2017-09-01',
	            id: ''
	        }, {
	            articleSign: '样例',
	            articleTitle: '魔篇使用帮助',
	            articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	            articleDate: '2017-09-01',
	            id: ''
	        }]), (0, _defineProperty3.default)(_ref, 'articleList', [{
	            articleSign: '公开',
	            articleTitle: '金钻厦门',
	            articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	            articleDate: '2017-8-31',
	            browse: 0,
	            praise: 0,
	            comments: 0,
	            id: '1',
	            corpus: '全部文章'
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门111',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 0,
	            praise: 0,
	            comments: 0,
	            id: '2',
	            corpus: '回收站'
	        }, {
	            articleSign: '私密',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	            articleDate: '2017-09-01',
	            browse: 0,
	            praise: 0,
	            comments: 0,
	            id: '3',
	            corpus: '诚毅学院点滴'
	        }, {
	            articleSign: '私密',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 0,
	            praise: 0,
	            comments: 0,
	            id: '4',
	            corpus: '诚毅学院点滴'
	        }, {
	            articleSign: '私密',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 0,
	            praise: 0,
	            comments: 0,
	            id: '5',
	            corpus: '诚毅学院点滴'
	        }, {
	            articleSign: '公开',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 0,
	            praise: 0,
	            comments: 0,
	            id: '6',
	            corpus: '诚毅学院点滴'
	        }]), (0, _defineProperty3.default)(_ref, 'articleListDelete', [{
	            articleSign: '已删除',
	            articleTitle: '金钻厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-8-31',
	            browse: 55,
	            praise: 48,
	            comments: 32,
	            id: ''
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 626,
	            praise: 47,
	            comments: 39,
	            id: ''
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 626,
	            praise: 47,
	            comments: 39,
	            id: ''
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 626,
	            praise: 47,
	            comments: 39,
	            id: ''
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 626,
	            praise: 47,
	            comments: 39,
	            id: ''
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 626,
	            praise: 47,
	            comments: 39,
	            id: ''
	        }, {
	            articleSign: '已删除',
	            articleTitle: '美丽厦门',
	            articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	            articleDate: '2017-09-01',
	            browse: 626,
	            praise: 47,
	            comments: 39,
	            id: ''
	        }]), _ref;
	    },
	    created: function created() {
	        //            var _this = this;
	        //            if(JSON.stringify(this.articleListDelete) == "[]"){//从对象解析出字符串
	        //                _this.isNoArticle = true;
	        //            };
	        //            _this.updateArticle();
	        this.open(function (res) {
	            modal.toast({ message: res.data });
	        });
	    },
	    mounted: function mounted() {
	        var domModule = weex.requireModule("dom");
	        domModule.addRule('fontFace', {
	            'fontFamily': 'iconfont',
	            'src': "url(\'http://cdn.rzico.com/weex/resources/fonts/iconfont.ttf\')"
	        });
	    },
	    methods: {
	        open: function open(callback) {
	            return _weex.stream.fetch({
	                method: 'GET',
	                type: 'json',
	                url: '/weex/member/article/list.jhtml'
	            }, callback);
	        },

	        switchArticle: function switchArticle(item) {
	            if (this.whichCorpus == item || this.whichCorpus == '全部文章') {
	                return true;
	            } else {
	                return false;
	            }
	            //                if(this.isAllArticle == false){
	            //                    if(item.articleSign == '已删除'){
	            //                        return true;
	            //                    }else{
	            //                        return false;
	            //                    }
	            //                }else{
	            //                    return true;
	            //                }
	        },
	        //            前往文章
	        goArticle: function goArticle(id) {
	            var _this = this;
	            _weex.event.openURL('http://192.168.1.107:8081/editor.weex.js?articleId=' + id, function () {
	                //                    _this.updateArticle();
	                modal.toast({ message: 1, duration: duration });
	            });
	        },
	        updateArticle: function updateArticle() {
	            var _this = this;
	            //            获取文章缓存。
	            _weex.event.findList(1, 'articleListTest1', 'desc', function (data) {
	                //                    modal.toast({message:data.data});
	                if (data.type == 'success') {
	                    for (var i = 0; i < data.data.length; i++) {
	                        var articleData = JSON.parse(data.data[i].value);
	                        _this.articleList.splice(0, 0, {
	                            articleSign: '草稿',
	                            articleTitle: articleData[0].title,
	                            articleCoverUrl: articleData[0].thumbnail,
	                            articleDate: '2017-09-23',
	                            browse: 0,
	                            praise: 0,
	                            comments: 0,
	                            id: articleData[0].id
	                        });
	                    }
	                } else {
	                    modal.alert({
	                        message: data.content,
	                        duration: 0.3
	                    });
	                }
	            });
	        },

	        toPage: function toPage(url) {
	            //                event.pageTo(url, false);
	            _weex.event.wxConfig(function (data) {
	                _weex.event.showToast(data.color);
	            });
	        },
	        jump: function jump(vueName) {
	            console.log('will jump');
	        },
	        allArticle: function allArticle(corpusName) {
	            var _this = this;
	            _this.whichCorpus = corpusName;
	            //                if(this.isAllArticle == true){
	            //
	            //                }else{
	            //                    this.isAllArticle = true;
	            //                    recycleScroll = scrollTop;
	            //                    setTimeout(function () {
	            //
	            //                        if(allArticleScroll > 424){
	            //                            let listHeight = allArticleScroll - 424;
	            //                            let positionIndex =parseInt( listHeight / 457);
	            //                            let offsetLength = - listHeight % 457;
	            //                            modal.toast({message:"positionIndex" + positionIndex + "offsetLength" + offsetLength})
	            //                            const el = _this.$refs.animationRef[positionIndex]//跳转到相应的cell
	            //                            dom.scrollToElement(el, {
	            //                                animated:false,
	            //                                offset:  -80 - offsetLength
	            //
	            //                            })
	            //                        }
	            //                    },50)
	            //                }
	        },
	        recycleSite: function recycleSite() {
	            var _this = this;
	            if (this.isAllArticle == false) {
	                modal.toast({ message: "相等" });
	            } else {
	                this.isAllArticle = false;
	                allArticleScroll = scrollTop;
	                setTimeout(function () {

	                    if (recycleScroll > 424) {
	                        var listHeight = recycleScroll - 424;
	                        var positionIndex = parseInt(listHeight / 457);
	                        var offsetLength = -listHeight % 457;
	                        modal.toast({ message: "positionIndex" + positionIndex + "offsetLength" + offsetLength });
	                        var el = _this.$refs.animationRef[positionIndex]; //跳转到相应的cell
	                        _weex.dom.scrollToElement(el, {
	                            animated: false,
	                            offset: -80 - offsetLength
	                        });
	                    }
	                }, 50);
	            }
	        },
	        swipeHappen: function swipeHappen(event) {
	            console.log(event);
	            //                console.log(event.direction);
	            //                if(event.direction == 'left'){
	            //                    this.isAllArticle = false;
	            //                }else if(event.direction == 'right'){
	            //                    this.isAllArticle = true;
	            //                }
	        },
	        //            点击屏幕时
	        ontouchstart: function ontouchstart(event, index) {
	            var _this = this;
	            if (animationPara == null || animationPara == '' || animationPara == 'undefinded') {} else {
	                animation.transition(animationPara, {
	                    styles: {
	                        transform: 'translateX(0)'
	                    },
	                    duration: 350, //ms
	                    timingFunction: 'ease-in-out', //350 duration配合这个效果目前较好
	                    //                      timingFunction: 'ease-out',
	                    needLayout: false,
	                    delay: 0 //ms
	                });
	            }
	            //                获取当前点击的元素。
	            animationPara = event.currentTarget;
	            //                canScroll 控制页面是否可以上下滑动
	            this.canScroll = true;
	        },
	        //            移动时
	        onpanmove: function onpanmove(event, index) {
	            var _this = this;
	            if (event.direction == 'right') {
	                _this.canScroll = false;
	                animation.transition(animationPara, {
	                    styles: {
	                        transform: 'translateX(0)'
	                    },
	                    duration: 350, //ms
	                    timingFunction: 'ease-in-out', //350 duration配合这个效果目前较好
	                    //                      timingFunction: 'ease-out',
	                    needLayout: false,
	                    delay: 0 //ms
	                });
	            } else if (event.direction == 'left') {
	                _this.canScroll = false;
	                //                  modal.toast({message:distance});
	                animation.transition(animationPara, {
	                    styles: {
	                        transform: 'translateX(-330)'
	                    },
	                    duration: 350, //ms
	                    timingFunction: 'ease-in-out', //350 duration配合这个效果目前较好
	                    //                      timingFunction: 'ease-out',
	                    needLayout: false,
	                    delay: 0 //ms
	                });
	            }
	        },
	        onpanend: function onpanend(event) {},
	        onloading: function onloading(event) {
	            var _this2 = this;

	            modal.toast({ message: '加载中...', duration: 1 });
	            this.showLoading = 'show';
	            setTimeout(function () {
	                var length = _this2.articleList.length;
	                for (var i = length; i < length + 2; ++i) {
	                    _this2.articleList.push({
	                        articleSign: '公开',
	                        articleTitle: '美丽厦门' + i,
	                        articleCoverUrl: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                        articleDate: '2017-09-01',
	                        browse: 626 + i,
	                        praise: 47 + i,
	                        comments: 39 + i
	                    });
	                }
	                _this2.showLoading = 'hide';
	            }, 1500);
	        },

	        scrollHandler: function scrollHandler(e) {
	            //                this.offsetX = e.contentOffset.x;
	            //                this.offsetY = e.contentOffset.y;
	            scrollTop = Math.abs(e.contentOffset.y);
	            //                modal.toast({message:scrollTop});
	            if (scrollTop < 424) {
	                recycleScroll = 0;
	                allArticleScroll = 0;
	            }
	        },
	        goCorpus: function goCorpus() {
	            _weex.event.openURL('http://192.168.1.107:8081/corpus.weex.js');
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 200:
/***/ (function(module, exports, __webpack_require__) {

	"use strict";

	exports.__esModule = true;

	var _defineProperty = __webpack_require__(201);

	var _defineProperty2 = _interopRequireDefault(_defineProperty);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	exports.default = function (obj, key, value) {
	  if (key in obj) {
	    (0, _defineProperty2.default)(obj, key, {
	      value: value,
	      enumerable: true,
	      configurable: true,
	      writable: true
	    });
	  } else {
	    obj[key] = value;
	  }

	  return obj;
	};

/***/ }),

/***/ 201:
/***/ (function(module, exports, __webpack_require__) {

	module.exports = { "default": __webpack_require__(202), __esModule: true };

/***/ }),

/***/ 202:
/***/ (function(module, exports, __webpack_require__) {

	__webpack_require__(203);
	var $Object = __webpack_require__(12).Object;
	module.exports = function defineProperty(it, key, desc) {
	  return $Object.defineProperty(it, key, desc);
	};


/***/ }),

/***/ 203:
/***/ (function(module, exports, __webpack_require__) {

	var $export = __webpack_require__(10);
	// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
	$export($export.S + $export.F * !__webpack_require__(20), 'Object', { defineProperty: __webpack_require__(16).f });


/***/ }),

/***/ 204:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('scroller', {
	    staticClass: ["wrapper"],
	    attrs: {
	      "showScrollbar": "false",
	      "offsetAccuracy": "0",
	      "scrollable": _vm.canScroll
	    },
	    on: {
	      "scroll": _vm.scrollHandler
	    }
	  }, [_c('div', {
	    ref: "topBox",
	    staticClass: ["topBox"]
	  }, [_c('image', {
	    staticClass: ["backgroundImage"],
	    attrs: {
	      "src": _vm.imageUrl
	    }
	  }), _c('div', {
	    staticClass: ["topHead"],
	    on: {
	      "click": function($event) {
	        _vm.toPage('member/manager.js')
	      }
	    }
	  }, [_c('image', {
	    staticClass: ["testImage"],
	    attrs: {
	      "src": _vm.imageUrl
	    }
	  }), _c('text', {
	    staticClass: ["userName"]
	  }, [_vm._v(_vm._s(_vm.userName))]), _c('text', {
	    staticClass: ["userSign"]
	  }, [_vm._v(_vm._s(_vm.userSign))])]), _c('div', {
	    staticClass: ["topBtnBox"]
	  }, [_c('div', {
	    staticClass: ["topBtnSmallBox", "topBtnOne"],
	    on: {
	      "click": function($event) {
	        _vm.jump()
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["topBtn", "topBtnBigFont"]
	  }, [_vm._v(_vm._s(_vm.collectNum))]), _c('text', {
	    staticClass: ["topBtn"]
	  }, [_vm._v("收藏")])]), _c('div', {
	    staticClass: ["topBtnSmallBox", "topBtnTwo"],
	    on: {
	      "click": function($event) {
	        _vm.jump()
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["topBtn", "topBtnBigFont"]
	  }, [_vm._v("¥ " + _vm._s(_vm.moneyNum))]), _c('text', {
	    staticClass: ["topBtn"]
	  }, [_vm._v("钱包")])]), _c('div', {
	    staticClass: ["topBtnSmallBox"]
	  }, [_c('text', {
	    staticClass: ["topBtn", "topBtnBigFont"]
	  }, [_vm._v(_vm._s(_vm.focusNum))]), _c('text', {
	    staticClass: ["topBtn"]
	  }, [_vm._v("关注")])])])]), _c('div', [_c('div', {
	    staticClass: ["corpusBox"]
	  }, [_c('scroller', {
	    staticStyle: {
	      flexDirection: "row",
	      width: "650px"
	    },
	    attrs: {
	      "scrollDirection": "horizontal"
	    }
	  }, [_c('div', {
	    staticClass: ["articleClass"]
	  }, _vm._l((_vm.memberArticleList), function(item) {
	    return _c('text', {
	      staticClass: ["allArticle"],
	      class: [_vm.whichCorpus == item.corpus ? 'active' : 'noActive'],
	      on: {
	        "click": function($event) {
	          _vm.allArticle(item.corpus)
	        }
	      }
	    }, [_vm._v(_vm._s(item.corpus))])
	  }))]), _c('div', {
	    staticStyle: {
	      width: "100px",
	      justifyContent: "center",
	      alignItems: "center"
	    },
	    on: {
	      "click": function($event) {
	        _vm.goCorpus()
	      }
	    }
	  }, [_c('text', {
	    staticStyle: {
	      fontSize: "35px"
	    },
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])])]), _c('div', [_c('transition-group', {
	    attrs: {
	      "name": "paraTransition",
	      "tag": "div"
	    }
	  }, _vm._l((_vm.articleList), function(item, index) {
	    return (_vm.switchArticle(item.corpus)) ? _c('div', {
	      key: index,
	      staticClass: ["articleBox"],
	      on: {
	        "click": function($event) {
	          _vm.goArticle(item.id)
	        },
	        "touchstart": function($event) {
	          _vm.ontouchstart($event, index)
	        },
	        "swipe": function($event) {
	          _vm.onpanmove($event, index)
	        }
	      }
	    }, [_c('div', {
	      staticClass: ["atricleHead"]
	    }, [_c('text', {
	      staticClass: ["articleSign"]
	    }, [_vm._v(_vm._s(item.articleSign))]), _c('text', {
	      staticClass: ["articleTitle"]
	    }, [_vm._v(_vm._s(item.articleTitle))])]), _c('div', [_c('image', {
	      staticClass: ["articleCover"],
	      attrs: {
	        "src": item.articleCoverUrl
	      }
	    })]), _c('div', {
	      staticClass: ["articleFoot"]
	    }, [_c('div', [_c('text', {
	      staticClass: ["articleDate"]
	    }, [_vm._v(_vm._s(item.articleDate))])]), (item.articleSign != '样例') ? _c('div', {
	      staticClass: ["relevantInfo"]
	    }, [_c('text', {
	      staticClass: ["relevantImage"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["relevantText"]
	    }, [_vm._v(_vm._s(item.browse))]), _c('text', {
	      staticClass: ["relevantImage", "testC"],
	      staticStyle: {
	        paddingBottom: "2px"
	      },
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["relevantText"]
	    }, [_vm._v(_vm._s(item.praise))]), _c('text', {
	      staticClass: ["relevantImage"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["relevantText"]
	    }, [_vm._v(_vm._s(item.comments))])]) : _vm._e()]), _c('div', {
	      staticClass: ["rightHidden"]
	    }, [_c('div', {
	      staticClass: ["rightHiddenSmallBox"]
	    }, [_c('div', {
	      staticClass: ["rightHiddenIconBox"]
	    }, [_c('text', {
	      staticClass: ["rightHiddenIcon"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["rightHiddenText"]
	    }, [_vm._v("编辑")])]), _c('div', {
	      staticClass: ["rightHiddenIconBox"]
	    }, [_c('text', {
	      staticClass: ["rightHiddenIcon", "redColor"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["rightHiddenText", "redColor"]
	    }, [_vm._v("删除")])])]), _c('div', {
	      staticClass: ["rightHiddenSmallBox"]
	    }, [_c('div', {
	      staticClass: ["rightHiddenIconBox"]
	    }, [_c('text', {
	      staticClass: ["rightHiddenIcon"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["rightHiddenText"]
	    }, [_vm._v("置顶")])]), _c('div', {
	      staticClass: ["rightHiddenIconBox"]
	    }, [_c('text', {
	      staticClass: ["rightHiddenIcon"],
	      style: {
	        fontFamily: 'iconfont'
	      }
	    }, [_vm._v("")]), _c('text', {
	      staticClass: ["rightHiddenText"]
	    }, [_vm._v("文集")])])])])]) : _vm._e()
	  }))], 1)]), _c('loading', {
	    staticClass: ["loading"],
	    attrs: {
	      "display": _vm.showLoading
	    },
	    on: {
	      "loading": _vm.onloading
	    }
	  }, [_c('text', {
	    staticClass: ["indicator"]
	  }, [_vm._v("Loading ...")])])], 1)
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ })

/******/ });