// { "framework": "Vue"} 

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 302);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function() {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		var result = [];
		for(var i = 0; i < this.length; i++) {
			var item = this[i];
			if(item[2]) {
				result.push("@media " + item[2] + "{" + item[1] + "}");
			} else {
				result.push(item[1]);
			}
		}
		return result.join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};


/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/

var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

var listToStyles = __webpack_require__(4)

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

module.exports = function (parentId, list, _isProduction) {
  isProduction = _isProduction

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[data-vue-ssr-id~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ }),

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "header",
    class: [_vm.classHeader(), _vm.border == true ? '' : 'cb']
  }, [_c('div', {
    staticClass: "nav_back",
    on: {
      "click": function($event) {
        _vm.goback('/')
      }
    }
  }, [_c('text', {
    staticClass: "nav_ico",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "nav"
  }, [_c('text', {
    staticClass: "nav_title"
  }, [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), (_vm.showComplete) ? _c('div', {
    staticClass: "navRightBox",
    on: {
      "click": function($event) {
        _vm.goComplete('/')
      }
    }
  }, [(_vm.complete != 'textIcon') ? _c('text', {
    staticClass: "nav_Complete nav_title"
  }, [_vm._v(_vm._s(_vm.complete))]) : _c('text', {
    staticClass: "nav_CompleteIcon",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]) : _vm._e()])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-019a21a0", module.exports)
  }
}

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(7);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("9b7c36f8", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0!../../node_modules/_less-loader@4.0.5@less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0!../../node_modules/_less-loader@4.0.5@less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 118:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(776)
__webpack_require__(777)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(210),
  /* template */
  __webpack_require__(617),
  /* scopeId */
  "data-v-88a2200a",
  /* cssModules */
  null
)
Component.options.__file = "/Users/ke/mopian/GitHubMoPian/mp/src/view/member/editor/editor.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] editor.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-88a2200a", Component.options)
  } else {
    hotAPI.reload("data-v-88a2200a", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(8);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("5944172c", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./navbar.vue", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-019a21a0&scoped=true!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./navbar.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 2:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/**
 * Created by zwwill on 2017/8/27.
 */
const resLocateURL = 'file://';
const resRemoteURL = 'http://cdn.rzico.com/weex/';
const websiteURL = 'http://dev.rzico.com';
const event = weex.requireModule('event');
const debug = true; //删掉该属性时请查找该页所有debug变量并删除变量
let utilsFunc = {
    initIconFont() {
        let domModule = weex.requireModule('dom');
        domModule.addRule('fontFace', {
            'fontFamily': "iconfont",
            'src': "url('" + resLocateURL + "resources/fonts/iconfont.ttf')"
        });
    },
    //获取本地资源
    locate(url) {
        const newUrl = resLocateURL + url;
        return newUrl;
    },
    //获取远程资源
    remote(url) {
        const newUrl = resRemoteURL + url;
        return newUrl;
    },
    //获取网站资源
    website(url) {
        const newUrl = websiteURL + url;
        return newUrl;
    },
    //获取URL参数
    getUrlParameter(name, dataUrl) {
        let url;
        if (dataUrl == null || dataUrl == undefined || dataUrl == '') {
            url = weex.config.bundleUrl;
        } else {
            url = dataUrl;
        }
        let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        let r = url.slice(url.indexOf('?') + 1).match(reg);
        if (r != null) {
            try {
                return decodeURIComponent(r[2]);
            } catch (_e) {
                return null;
            }
        }
        return null;
    },
    message(_type, _content, _data) {
        return {
            type: _type,
            content: _content,
            data: _data
        };
    },
    //判空
    isNull(value) {
        if (value == null || value == undefined || value == '' || value == 'undefined') {
            return true;
        } else {
            return false;
        }
    },
    //获取缩略图
    thumbnail(url, w, h) {
        //获取屏幕宽度计算得出比例
        let proportion = weex.config.env.deviceWidth / 750;
        //                获取缩略图的宽高
        w = parseInt(w * proportion);
        h = parseInt(h * proportion);
        if (url.substring(0, 11) == "http://cdnx") {
            return url + "?x-oss-process=image/resize,w_" + w + ",h_" + h + "";
        } else if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + w + "w_" + h + "h_1e_1c_100Q";
        } else {
            return url;
        }
    },
    //获取全屏的高度尺寸,可传入父组件的导航栏高度进行适配
    fullScreen(topHeight) {
        //减1是为了能触发loading，不能够高度刚刚好
        topHeight = topHeight == '' ? 0 : topHeight - 1;
        return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - topHeight;
    },
    //模糊图片，r , s  为 1-50，超大超模糊
    blur(url, r, s) {
        if (url.substring(0, 10) == "http://cdn") {
            return url + "@" + r + "-" + s + "bl";
        } else {
            return url;
        }
    },
    //获取文章URL地址
    articleUrl(template, id) {
        template = template == '' ? 't1001' : template;
        return websiteURL + "/" + template + "?id=" + id;
    },
    debug(msg) {
        if (debug) {
            event.toast(msg);
        }
    },
    //  获取字符串的字符总长度
    getLength(e) {
        var name = e;
        var len = 0;
        for (let i = 0; i < name.length; i++) {
            var a = name.charAt(i);
            if (a.match(/[^\x00-\xff]/ig) != null) {
                len += 2;
            } else {
                len += 1;
            }
        }
        return len;
    },
    //    将过长的字符串换成 XXX...XXX格式
    changeStr(e) {
        return e.substr(0, 4) + '...' + e.substr(-4);
    },
    //js中用正则表达式 过滤特殊字符, 校验所有输入域是否含有特殊符号 (无法过滤 \ )
    //  searchFilter(s) {
    //         event.toast(s);
    //         var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）&mdash;—|{}【】‘；：”“'。，、？]");
    //         var rs = "";
    //         for (var i = 0; i < s.length; i++) {
    //             rs = rs + s.substr(i, 1).replace(pattern,'');
    //         }
    //         return rs;
    //     }

    //老的二维码转换成新格式
    qr2scan(e) {
        let type = this.getUrlParameter("type", e);
        let code = this.getUrlParameter("no", e);
        if (type == "paybill") {
            return websiteURL + "/q/818804" + code + ".jhtml";
        } else if (type == "card_active") {
            return websiteURL + "/q/818801" + code + ".jhtml";
        } else {
            return e;
        }
    },
    //    二维码读取内容
    readScan(e, callback) {
        e = this.qr2scan(e);
        let backData = {};
        //二维码字段截取. indexOf 没找到时返回-1， 此时如果2个indexof都没找到 那么 e.substring（-1 + 3 ，-1）,e的长度会变为2
        // let subData = e.substring(e.indexOf("/q/8") + 3,e.indexOf(".jhtml"));

        let start = e.indexOf("/q/8");
        let end = e.indexOf(".jhtml");
        var subData = null;
        if (start != -1 && end != -1) {
            subData = e.substring(start + 3, end);
        }
        //判断是不是web  code'000000'为无效二维码 '999999'为webView；
        if (subData == null) {
            //如果没有找到q/ 和 .jhtml中的字端，就执行该段代码
            if (e.substring(0, 4) == 'http' && debug) {
                let data = {
                    type: 'webView',
                    code: '999999'
                };
                backData = this.message('success', 'webView', data);
            } else {
                let data = {
                    type: 'error',
                    code: '000000'
                };
                backData = this.message('error', '无效二维码', data);
            }
            callback(backData);
        } else {
            //截取11位的判断码
            let type = subData.substring(0, 6);
            let code = subData.slice(6);
            let data = {
                type: type,
                code: code
            };
            if (code == '000000') {
                backData = this.message('error', '无效二维码', data);
            } else {
                backData = this.message('success', '扫描成功', data);
            }
            callback(backData);
        }
    },
    //判断用户是否只输入了空格
    isAllEmpty(str) {
        if (str.replace(/ /g, "").length == 0) {
            return true;
        } else {
            return false;
        }
    },
    //判断设备型号
    device: function () {
        let s = weex.config.env.deviceModel;
        if (this.isNull(s)) {
            return "";
        } else {
            if (s.indexOf("V1") > 0) {
                return "V1";
            } else if (s.indexOf("10,3") > 0 || s.indexOf("10,6") > 0) {
                return 'IPhoneX';
            } else {
                return s;
            }
        }
    },

    //    登录主页的轮播图控制
    indexMt() {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'indexMtV1';
            } else if (s == 'IPhoneX') {
                return 'indexMtIPhoneX';
            } else {
                return s;
            }
        }
    },

    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addTopV1';
            } else if (s == 'IPhoneX') {
                return 'addTopIPhoneX';
            } else {
                return s;
            }
        }
    },
    //   会员首页 作者专栏 顶部信息栏
    addInfo: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addInfoV1';
            } else if (s == 'IPhoneX') {
                return 'addInfoIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    判断设备型号为fix定位的元素添加高度 (会员首页 作者专栏 顶部设置跟返回按钮)
    addBgImg: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'addBgImgV1';
            } else if (s == 'IPhoneX') {
                return 'addBgImgIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    hideCorpus: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'hideCorpusV1';
            } else if (s == 'IPhoneX') {
                return 'hideCorpusIPhoneX';
            } else {
                return s;
            }
        }
    },
    //    控制滑动时文集box的显示
    pageTop: function () {
        let s = this.device();
        if (this.isNull(s)) {
            return "";
        } else {
            if (s == 'V1') {
                return 'pageTopV1';
            } else if (s == 'IPhoneX') {
                return 'pageTopIPhoneX';
            } else {
                return s;
            }
        }
    },

    //判断设备系统是不是ios
    isIosSystem: function () {
        let s = weex.config.env.osName;
        if (s == 'iOS') {
            return true;
        } else {
            return false;
        }
    },

    resolvetimefmt: function (value) {
        //value 传进来是个整数型，要判断是10位还是13位需要转成字符串。这边的方法是检测13位的时间戳 所以要*1000；并且转回整型。安卓下，时间早了8个小时
        if (value.toString().length == 10) {
            value = parseInt(value) * 1000;
        } else {
            value = parseInt(value);
        }
        // 返回处理后的值
        var date = new Date(value);

        var d2 = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

        date = new Date(d2 + 28800000);

        var y = date.getUTCFullYear();
        var m = date.getUTCMonth() + 1;
        var d = date.getUTCDate();
        var h = date.getUTCHours();
        var i = date.getUTCMinutes();
        var s = date.getUTCSeconds();
        if (m < 10) {
            m = '0' + m;
        }
        if (d < 10) {
            d = '0' + d;
        }
        if (h < 10) {
            h = '0' + h;
        }
        if (i < 10) {
            i = '0' + i;
        }
        if (s < 10) {
            s = '0' + s;
        }
        let timeObj = {
            y: y,
            m: m,
            d: d,
            h: h,
            i: i,
            s: s
        };
        return timeObj;
    },
    //返回格式 2017-09-01
    ymdtimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d;
    },
    //返回格式 2017-09-01 06:35:59
    ymdhistimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '-' + timeObj.m + '-' + timeObj.d + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 2017年09月01日 06:35:59
    ymdhisdayfmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);

        return timeObj.y + '年' + timeObj.m + '月' + timeObj.d + '日' + ' ' + timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    },
    //返回格式 06:35:59
    histimefmt: function (value) {
        if (value == '' || value == null || value == undefined) {
            return value;
        }
        let timeObj = this.resolvetimefmt(value);
        return timeObj.h + ':' + timeObj.i + ':' + timeObj.s;
    }
};

/* harmony default export */ __webpack_exports__["a"] = (utilsFunc);

/***/ }),

/***/ 210:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_fetch__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__include_navbar_vue__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__include_navbar_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__include_navbar_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__assets_utils__ = __webpack_require__(2);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




const storage = weex.requireModule('storage');
const event = weex.requireModule('event');
const album = weex.requireModule('album');
var modal = weex.requireModule('modal');
const stream = weex.requireModule('stream');
var lastIndex = -1;
var musicId = -1;
/* harmony default export */ __webpack_exports__["default"] = ({
    data: function () {
        return {
            toSendArticle: false, //控制进度条 遮罩显示
            currentPro: 0, //当前进度
            proTotal: 0, //总的进度
            processWidth: 0, //进度条宽度
            articleId: '',
            refreshing: false,
            firstPlusShow: true,
            coverImage: __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/background.png'),
            setTitle: '点击设置标题',
            addMusic: '添加音乐',
            musicName: '',
            paraList: [],
            voteList: [],
            proportion: '', //缩略图的比例
            serveCover: '', //用来保存图片上传服务器后存储服务器图片路径，避免覆盖图片时产生闪屏
            catalogId: '',
            publish: false,
            sortStatus: '0,',
            timestamp: '',
            articleTemplates: [], //文章段落数组
            musicData: '', //音乐数据
            voteData: [], //投票的数组
            hadChange: 0,
            //                缓存有用
            articleOption: {
                articleCatalog: { count: 0 },
                articleCategory: {},
                authority: 'draft',
                isPitch: false,
                isPublish: false,
                isTop: false
            },
            hits: 0,
            laud: 0,
            products: [],
            isReview: 0,
            clicked: false
        };
    },
    filters: {
        //            过滤html标签
        htmlDeal: function (value) {
            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(value)) {
                return value;
            }
            //                将h1-h5换成\n
            let takeEnter = value.replace(/<\/h[0-9]>/g, "\n");
            //                将html标签替换，可能遗留空格
            let nbspText = takeEnter.replace(/<\/?.+?>/g, "");
            //                将空格 &nbsp; 替换成 。
            let spaceText = nbspText.replace(/&nbsp;/g, " ");
            return spaceText;
            //                //                将空格去除
            ////                var onlyText=spaceText.replace(/ /g,"");
        },
        watchThumbImg: function (value) {
            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(value)) {
                return __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/text.png');
            } else {
                return value;
            }
        }
    },
    computed: {
        voteImg: function () {
            return __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/vote.png');
        }
    },
    components: {
        navbar: __WEBPACK_IMPORTED_MODULE_1__include_navbar_vue___default.a
    },
    props: {
        title: { default: "编辑" },
        complete: { default: "完成" }
    },
    created: function () {
        __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].initIconFont();
        var _this = this;
        //            获取当前时间戳 作为唯一标识符key
        this.timestamp = Math.round(new Date().getTime() / 1000);
        //            bundleUrl = new String(bundleUrl);
        //            取当前页面rul，将musicId取出来
        var bundleUrl = this.$getConfig().bundleUrl;
        var getVal = bundleUrl.split('?')[1];
        //          创建文章编辑（首次）
        if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(getVal)) {

            //       多选图片
            //      调用安卓的相册
            var _this = this;
            //判断是否第一次编辑该文章
            var findDelete = {
                type: 'articleDraft',
                key: '0'
            };
            event.find(findDelete, function (delData) {
                if (delData.type == 'success' && delData.data != '') {
                    //从缓存读取数据 写入界面
                    _this.readData(findDelete);
                } else {
                    album.openAlbumMuti(
                    //选完图片后触发回调函数
                    function (data) {
                        if (data.type == 'success') {
                            _this.coverImage = data.data[0].originalPath;
                            //                    data.data里存放的是用户选取的图片路径
                            for (let i = 0; i < data.data.length; i++) {
                                _this.paraList.push({
                                    //原图
                                    paraImage: data.data[i].originalPath,
                                    //小缩略图
                                    thumbnailImage: data.data[i].thumbnailSmallPath,
                                    mediaType: "image",
                                    paraText: '',
                                    show: true,
                                    serveThumbnail: '',
                                    //                                            对象id
                                    id: 0,
                                    //                                            第三方链接
                                    url: ''
                                });
                                _this.saveDraft();
                            }
                        } else {
                            event.closeURL();
                        }
                    });
                }
            });
        } else {
            //再次文章编辑
            _this.delOnceDraft('noclose');
            var op = getVal.split('=');
            if (op[0] == 'articleId') {
                let options = {
                    type: 'article',
                    key: op[1]
                };
                _this.articleId = op[1];
                if (_this.articleId.length == 19) {//19位的id为草稿文章
                } else {
                    __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__assets_fetch__["a" /* GET */])('weex/member/article/option.jhtml?id=' + _this.articleId, function (data) {
                        if (data.type == 'success' && data.data != '') {
                            _this.catalogId = data.data.articleCatalog.id;
                        }
                    }, function (err) {
                        event.toast(err.content);
                        return;
                    });
                };
                //从缓存读取数据 写入界面
                _this.readData(options);
            } else if (op[0] == 'goodsStorageName') {
                //读取商品缓存并写入页面之中。
                storage.getItem(op[1], function (e) {
                    if (e.result == 'success') {
                        var goodsInfo = JSON.parse(e.data);
                        _this.coverImage = goodsInfo.thumbnail;
                        _this.setTitle = goodsInfo.name;
                        //                    data.data里存放的是用户选取的图片路径
                        _this.paraList.push({
                            //原图
                            paraImage: goodsInfo.thumbnail,
                            //小缩略图
                            thumbnailImage: goodsInfo.thumbnail,
                            mediaType: "product",
                            paraText: '',
                            show: true,
                            serveThumbnail: '',
                            //                                            对象id
                            id: goodsInfo.id,
                            //                                            第三方链接
                            url: ''
                        });
                        //                            存储页面数据
                        _this.saveDraft();
                        //                          把缓存删除
                        storage.removeItem(op[1], e => {});
                    }
                });
            };
        };
    },
    methods: {
        //从缓存读取数据 写入界面
        readData(options) {
            let _this = this;
            event.find(options, function (data) {
                if (data.type == 'success' && data.data != '') {
                    let articleData = JSON.parse(data.data.value);
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(data.data.sort)) {
                        //                            保存置顶状态。
                        _this.sortStatus = data.data.sort.substring(0, 2);
                    }
                    _this.setTitle = articleData.title;
                    _this.coverImage = articleData.thumbnail;
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(articleData.music.name)) {
                        _this.musicName = articleData.music.name;
                    }
                    _this.publish = articleData.articleOption.isPublish;
                    _this.articleOption = articleData.articleOption, _this.hits = articleData.hits, _this.laud = articleData.laud, _this.products = articleData.products, _this.review = articleData.isReview, musicId = articleData.music.id;
                    let templatesData = articleData.templates;
                    for (let i = 0; i < templatesData.length; i++) {
                        let paraId = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(templatesData[i].id) ? 0 : templatesData[i].id;
                        let paraUrl = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(templatesData[i].url) ? '' : templatesData[i].url;
                        _this.paraList.push({
                            //原图
                            paraImage: templatesData[i].original,
                            //小缩略图
                            thumbnailImage: templatesData[i].thumbnail,
                            paraText: templatesData[i].content,
                            show: true,
                            mediaType: templatesData[i].mediaType,
                            serveThumbnail: '', //用来保存图片上传服务器后存储服务器图片路径，避免覆盖图片时产生闪屏
                            //          对象id
                            id: paraId,
                            //                                            第三方链接
                            url: paraUrl
                        });
                    }
                    //                            投票
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(articleData.votes)) {
                        articleData.votes.forEach(function (item) {
                            let startDate = '';
                            let startTime = '';
                            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.expire)) {
                                startDate = '无截止时间';
                            } else {
                                let time = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].ymdhistimefmt(item.expire);
                                startDate = time.substring(0, 10);
                                startTime = time.substring(11, 19);
                            }
                            let optionIndex = 0;
                            switch (item.voteType) {
                                case 'radiobox':
                                    optionIndex = 0;
                                    break;
                                case 'checkbox':
                                    optionIndex = 1;
                                    break;
                                case 'nolimit':
                                    optionIndex = 2;
                                    break;
                                default:
                                    break;
                            }
                            //选项
                            let optionBox = [];
                            item.options.forEach(function (value) {
                                optionBox.push({
                                    textAreaMessage: value,
                                    textHeight: '48',
                                    rowsNum: '1',
                                    editSign: -1
                                });
                            });

                            _this.voteList.push({
                                chooseDate: startDate,
                                chooseTime: startTime,
                                optionsIndex: optionIndex,
                                textAreaTitle: item.title,
                                pageBox: optionBox
                            });
                        });
                    }
                } else {
                    if (_this.articleId.length == 19) {
                        event.toast('本地数据已被删除');
                        event.closeURL();
                        return;
                    }
                    //                        从服务器获取文章信息并存入缓存
                    _this.getServerArticle(function () {
                        let options = {
                            type: 'article',
                            key: _this.articleId
                        };
                        _this.readData(options);
                    });
                };
            });
        },
        //           从服务器获取文章信息并存入缓存
        getServerArticle(callback) {
            let _this = this;
            __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__assets_fetch__["a" /* GET */])('weex/member/article/view.jhtml?id=' + _this.articleId, function (res) {
                if (res.data != '' && res.type == 'success') {
                    //                                   将服务器的缩略图换成原图的缩略图
                    //                                    res.data.templates.forEach(function (item) {
                    //                                        item.thumbnail = utils.thumbnail(item.original,155,155);
                    //                                    })
                    let resDataStr = JSON.stringify(res.data);
                    let saveData = {
                        type: "article",
                        key: res.data.id,
                        value: resDataStr,
                        sort: '0,' + res.data.modifyDate,
                        keyword: ',[' + _this.catalogId + '],' + _this.setTitle + ','
                    };
                    event.save(saveData, function (data) {
                        if (data.type == 'success') {
                            callback();
                        } else {
                            event.toast(data.content);
                        }
                    });
                }
            }, function (err) {
                event.toast(err.content);
            });
        },
        //            保存临时草稿
        saveDraft(callback) {
            let _this = this;
            //                将数据保存到变量里
            this.savePage();
            var allPageData = {
                articleOption: this.articleOption,
                hits: this.hits,
                laud: this.laud,
                products: this.products,
                review: this.isReview,
                id: this.articleId,
                isDraft: true,
                modifyDate: this.timestamp,
                music: this.musicData,
                templates: this.articleTemplates,
                thumbnail: this.coverImage,
                title: this.setTitle,
                votes: this.voteData
            };
            allPageData = JSON.stringify(allPageData);
            var storageType;
            var storageKey;
            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.articleId)) {
                storageType = "articleDraft";
                storageKey = '0';
            } else {
                storageType = "article";
                storageKey = this.articleId;
            }
            let draftOptions = {
                type: storageType,
                key: storageKey,
                value: allPageData,
                sort: _this.sortStatus + _this.timestamp,
                keyword: ',[' + _this.catalogId + '],' + _this.setTitle + ','
            };
            event.save(draftOptions, function (data) {
                if (data.type == 'success' && !__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(_this.articleId)) {

                    //                                    全局监听文章变动
                    let listenData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '文章改变', '');
                    event.sendGlobalEvent('onArticleChange', listenData);
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(callback)) {
                        callback();
                    }
                } else if (data.type == 'success') {
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(callback)) {
                        callback();
                    }
                } else {
                    event.toast(data.content);
                }
            });
        },

        //            控制进度条
        ctrlProcess(data) {
            this.processWidth = parseInt(data.data) * 5;
            if (this.processWidth == 500) {
                this.currentPro++;
            };
        },

        //            设置文章标题
        articleTitle: function (title) {
            let _this = this;
            if (title == '点击设置标题') {
                title = '';
            };
            let textData = {
                autograph: title
            };
            textData = JSON.stringify(textData);
            storage.setItem('articleTitle', textData, e => {
                event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('widget/autograph.js?name=articleTitle'), function (message) {
                    if (message.type == 'success' && !__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(message.data) && !__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(message.data.text)) {
                        _this.setTitle = message.data.text;
                        _this.hadChange = 1;
                        //                            if(utils.isNull(_this.articleId)){
                        //                        临时保存到缓存
                        _this.saveDraft();
                        //                            }
                    }
                });
            });
        },
        //            段落里的文本编辑
        editorText(index) {
            var _this = this;

            //                if(_this.paraList[index].mediaType == 'product'){
            //                    event.openURL(utils.locate('view/shop/goods/manage.js?from=editor'),function (data) {
            //                        if (data.type == 'success') {
            //                            _this.paraList[index].paraImage = data.data.thumbnail;
            //                            _this.paraList[index].thumbnailImage = data.data.thumbnail;
            //                            _this.paraList[index].paraText = data.data.name;
            ////                    添加修改标志
            //                            _this.hadChange = 1;
            ////                        if(utils.isNull(_this.articleId)){
            ////                        临时保存到缓存
            //                            _this.saveDraft();
            ////                        }
            //                        }
            //                    })
            //                    return;
            //                }

            event.openEditor(_this.paraList[index].paraText, function (data) {
                if (data.data != '') {
                    //                    将返回回来的html数据赋值进去
                    _this.paraList[index].paraText = data.data;
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            返回
        goBack: function () {
            let _this = this;
            //                判断是草稿还是已经发布文章
            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.articleId) || this.articleId.length == 19) {
                modal.confirm({
                    message: '请选择方式?',
                    duration: 0.3,
                    okTitle: '删除草稿',
                    cancelTitle: '存草稿'
                }, function (value) {
                    if (value == '存草稿') {
                        if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(_this.articleId)) {
                            //                                生成6位随机数
                            var Num = "";
                            for (var i = 0; i < 6; i++) {
                                Num += Math.floor(Math.random() * 10);
                            }
                            //            获取当前时间戳 作为唯一标识符key
                            _this.articleId = Math.round(new Date().getTime()) + Num;
                        }
                        _this.saveDraft(function () {
                            _this.delOnceDraft();
                        });
                    } else if (value == '删除草稿') {
                        _this.deleteDraft();
                    }
                });
            } else {
                //                    判断是否有修改过
                if (this.hadChange == 1) {
                    modal.confirm({
                        message: '请选择方式?',
                        duration: 0.3,
                        okTitle: '撤销编辑',
                        cancelTitle: '存草稿'
                    }, function (value) {
                        if (value == '存草稿') {
                            _this.saveDraft(function () {
                                let E = {
                                    isDone: 'complete'
                                };
                                let backData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '成功', E);
                                event.closeURL(backData);
                            });
                        } else if (value == '撤销编辑') {
                            _this.getServerArticle(function () {
                                //                                    全局监听文章变动
                                let listenData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '文章改变', '');
                                event.sendGlobalEvent('onArticleChange', listenData);
                                event.closeURL();
                            });
                        }
                    });
                } else {
                    event.closeURL();
                }
            }
        },
        //            删除临时缓存和草稿缓存
        deleteDraft(close) {
            let _this = this;
            var storageType;
            var storageKey;
            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.articleId)) {
                storageType = "articleDraft";
                storageKey = '0';
            } else {
                if (this.articleId.length != 19) {
                    return;
                }
                storageType = "article";
                storageKey = this.articleId;
            }
            //                                    判断是否第一次编辑该文章
            let findDel = {
                type: storageType,
                key: storageKey
            };
            event.find(findDel, function (delData) {
                if (delData.type == 'success' && delData.data != '') {
                    //  将临时缓存删除;
                    let delOption = {
                        type: storageType,
                        key: storageKey
                    };
                    event.delete(delOption, function (data) {
                        if (data.type == 'success' && !__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(_this.articleId)) {
                            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(close)) {
                                //                                    全局监听文章变动
                                let listenData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '文章改变', '');
                                event.sendGlobalEvent('onArticleChange', listenData);
                                event.closeURL();
                            }
                        } else if (data.type == 'success') {
                            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(close)) {
                                event.closeURL();
                            }
                        }
                    });
                } else {
                    event.toast(delData.content);
                }
            });
        },
        //            删除临时缓存
        delOnceDraft(close) {
            let _this = this;
            //   将临时草稿删除
            let findDel = {
                type: 'articleDraft',
                key: '0'
            };
            event.find(findDel, function (delData) {
                if (delData.type == 'success' && delData.data != '') {
                    //  将临时缓存删除;
                    let delOption = {
                        type: 'articleDraft',
                        key: '0'
                    };
                    event.delete(delOption, function (data) {
                        if (data.type == 'success') {
                            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(close)) {
                                let E = {
                                    isDone: 'complete'
                                };
                                let backData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '成功', E);
                                event.closeURL(backData);
                            }
                        } else {
                            event.toast(data.content);
                        }
                    });
                } else {
                    if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(close)) {
                        event.closeURL();
                    }
                }
            });
        },
        //            完成
        goComplete: function () {
            var _this = this;
            if (this.setTitle == '点击设置标题') {
                event.toast('请设置标题');
                return;
            }
            //                判断封面是否有值。
            if (this.coverImage == __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/background.png')) {
                event.toast('请设置封面');
                return;
            }
            var imageNum = 0;
            //                上传时判断至少要有一张图,或者一个商品;
            _this.paraList.forEach(function (item) {
                if ((item.mediaType == 'image' || item.mediaType == 'product') && item.paraImage != '') {
                    imageNum++;
                }
            });
            if (imageNum == 0) {
                //                        modal.toast({message: '至少要保留一张图片', duration: 0.5});
                event.toast('至少要有一张图片');
                return;
            }

            //防止重复点击按钮
            if (this.clicked) {
                return;
            }
            this.clicked = true;

            this.toSendArticle = true;
            this.proTotal = 0;
            //                判断封面图片是否已上传过
            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.coverImage) && this.coverImage.substring(0, 4) != 'http') {
                this.proTotal++;
            };
            //                判断段落图片是否已上传
            this.paraList.forEach(function (item) {
                if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.paraImage) && item.paraImage.substring(0, 4) != 'http') {
                    _this.proTotal++;
                }
            });
            ////                获取设备宽度
            //                let devWidth = weex.config.env.deviceWidth;
            ////                获取缩略图的宽高
            //                _this.proportion = parseInt(155 * devWidth/750);
            var frontcoverUrl = '';
            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.coverImage)) {
                frontcoverUrl = this.coverImage.substring(0, 4);
            }
            //                event.toast(frontcoverUrl);
            if (frontcoverUrl == 'http') {
                //                    event.toast('1');
                _this.serveCover = this.coverImage;
                _this.sendImage(0);
            } else {
                //                将封面上传服务器
                event.upload(this.coverImage, function (data) {
                    if (data.type == 'success') {
                        //这边会由于避免重复渲染而需要再次向服务器上传该图片
                        _this.serveCover = data.data;
                        //                        上传段落图片
                        _this.sendImage(0);
                    } else {
                        _this.toSendArticle = false;
                        event.toast(data.content);
                        return;
                    }
                }, function (data) {
                    _this.ctrlProcess(data);
                });
            }
            //                防止重复点击
            _this.clicked = false;
        },
        //上传图片到服务器
        sendImage(sendIndex) {
            var _this = this;
            //                var frontUrl;
            let sendLength = _this.paraList.length; //获取图片数组总长度
            var mediaType = _this.paraList[sendIndex].mediaType;
            var frontUrl = '';
            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(_this.paraList[sendIndex].paraImage)) {
                frontUrl = _this.paraList[sendIndex].paraImage.substring(0, 4);
            }
            //                if(mediaType == 'image') {
            //                    modal.toast({message:frontUrl,duration:1});
            //                }else if(mediaType == 'video'){//如果是视频
            //                    frontUrl = _this.paraList[sendIndex].thumbnailImage.substring(0,5);
            //
            //                    modal.toast({message:frontUrl,duration:1});
            //                }
            //                判断是否已经是服务器图片
            if (frontUrl == 'http') {
                if (mediaType == 'image' || mediaType == 'product') {
                    //                    如果已经是http的图片 就直接将图片赋予要上传的变量；
                    _this.paraList[sendIndex].serveThumbnail = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].thumbnail(_this.paraList[sendIndex].paraImage, 155, 155);
                } else if (mediaType == 'video') {
                    //如果是视频就将缩略图进行赋值
                    _this.paraList[sendIndex].serveThumbnail = _this.paraList[sendIndex].thumbnailImage;
                }
                sendIndex++;
                //                        判断是否最后一张图
                if (sendIndex < sendLength) {
                    //                            回调自己自己
                    _this.sendImage(sendIndex);
                } else {
                    //进行上传文章
                    _this.realSave();
                }
            } else if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(_this.paraList[sendIndex].paraImage)) {
                //判断是否只有文字
                _this.paraList[sendIndex].serveThumbnail = '';
                sendIndex++;
                //                        判断是否最后一张图
                if (sendIndex < sendLength) {
                    //                            回调自己自己
                    _this.sendImage(sendIndex);
                } else {
                    //进行上传文章
                    _this.realSave();
                }
            } else {
                event.upload(_this.paraList[sendIndex].paraImage, function (data) {
                    if (data.type == 'success') {
                        _this.paraList[sendIndex].paraImage = data.data;
                        //                            判断是图片还是视频
                        if (mediaType == 'image' || mediaType == 'product') {
                            //                            向后台获取缩略图
                            _this.paraList[sendIndex].serveThumbnail = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].thumbnail(data.data, 155, 155);
                            //                                    因为异步操作,所以要分别在if elseif里写下列代码
                            sendIndex++;
                            //                        判断是否最后一张图
                            if (sendIndex < sendLength) {
                                //                            回调自己自己
                                _this.sendImage(sendIndex);
                            } else {
                                //进行上传文章
                                _this.realSave();
                            }
                        } else if (mediaType == 'video') {
                            //                                将视频的封面上传
                            event.upload(_this.paraList[sendIndex].thumbnailImage, function (e) {
                                if (e.type == 'success') {
                                    //                            向后台获取缩略图 (视频不需要获取缩略图)
                                    _this.paraList[sendIndex].serveThumbnail = e.data;
                                    //                                        event.toast(_this.paraList[sendIndex].serveThumbnail);
                                } else {
                                    //上传失败
                                    _this.toSendArticle = false;
                                    _this.currentPro = 0; //当前进度
                                    _this.proTotal = 0; //总的进度
                                    _this.processWidth = 0; //进度条宽度
                                    event.toast(e.content);
                                    return;
                                    //                                        这边出错 11.30
                                }
                                //                                    因为异步操作,所以要分别在if elseif里写下列代码
                                sendIndex++;
                                //                        判断是否最后一张图
                                if (sendIndex < sendLength) {
                                    //                            回调自己自己
                                    _this.sendImage(sendIndex);
                                } else {
                                    //进行上传文章
                                    _this.realSave();
                                }
                            }, function (data) {});
                        }
                    } else {
                        //上传失败
                        _this.toSendArticle = false;
                        _this.currentPro = 0; //当前进度
                        _this.proTotal = 0; //总的进度
                        _this.processWidth = 0; //进度条宽度
                        event.toast(data.content);
                        return;
                    }
                }, function (data) {
                    //                    上传进度
                    _this.ctrlProcess(data);
                });
            }
        },
        //            将页面上的数据存储起来
        savePage() {

            //                每次保存前 将下列3个变量重新置空;
            this.articleTemplates = []; //文章段落数组
            this.musicData = ''; //音乐数据
            this.voteData = []; //投票的数组

            let _this = this;
            this.musicData = {
                name: _this.musicName,
                id: musicId
                //                let voteData = [];
                //                投票组
            };this.voteList.forEach(function (item) {
                //                    投票选项
                let voteOptions = [];
                item.pageBox.forEach(function (value) {
                    voteOptions.push(value.textAreaMessage);
                });
                let expireTime = '';
                if (item.chooseDate == '无截止时间') {} else {
                    let merge = item.chooseDate + ' ' + item.chooseTime + ':00';
                    let mergeMore = new Date(Date.parse(merge.replace(/-/g, "/")));
                    expireTime = mergeMore.getTime() / 1000;
                }
                _this.voteData.push({
                    title: item.textAreaTitle,
                    expire: expireTime,
                    voteType: item.optionsIndex,
                    options: voteOptions
                });
                //                    event.toast(voteData);
            });
            //                var articleTemplates = [];
            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.articleId) && this.articleId.length == 19) {
                //判断id为19位的是草稿，或者有文章id时。
                var uploadThumbnailImg;
                this.paraList.forEach(function (item) {
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.serveThumbnail)) {
                        uploadThumbnailImg = item.serveThumbnail;
                    } else {
                        uploadThumbnailImg = item.thumbnailImage;
                    }
                    _this.articleTemplates.push({
                        thumbnail: uploadThumbnailImg,
                        original: item.paraImage,
                        mediaType: item.mediaType,
                        content: item.paraText,
                        //          对象id
                        id: parseInt(item.id),
                        //                                            第三方链接
                        url: item.url
                    });
                });
            } else {
                var uploadThumbnail;
                //                    如果是临时缓存 是没有上传过的本地图片； thumbnail:item.thumbnailImage,
                this.paraList.forEach(function (item) {
                    if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.paraImage) && item.paraImage.substring(0, 4) == 'http' && !__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(item.serveThumbnail)) {
                        uploadThumbnail = item.serveThumbnail;
                    } else {
                        uploadThumbnail = item.thumbnailImage;
                    }
                    _this.articleTemplates.push({
                        thumbnail: uploadThumbnail,
                        original: item.paraImage,
                        mediaType: item.mediaType,
                        content: item.paraText,
                        //          对象id
                        id: parseInt(item.id),
                        //                                            第三方链接
                        url: item.url
                    });
                });
            }
        },
        //            图片上传后，正式将文章数据上传服务器
        realSave() {
            var _this = this;
            //                将页面上的数据存储起来
            this.savePage();
            //                判断是再次编辑还是初次编辑;
            let sendId = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(_this.articleId) ? _this.timestamp : _this.articleId;
            let articleData = {
                thumbnail: this.serveCover,
                music: _this.musicData,
                templates: _this.articleTemplates,
                id: sendId,
                title: _this.setTitle,
                votes: _this.voteData,
                isDraft: false
            };
            //                转成json字符串后上传服务器
            articleData = JSON.stringify(articleData);
            //                utils.debug(articleData);
            //                网络请求，保存文章
            __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__assets_fetch__["b" /* POST */])('weex/member/article/submit.jhtml', articleData).then(function (res) {
                //                        utils.debug(res);
                if (res.data != '' && res.type == 'success') {
                    //                            _this.articleId = res.data.id;
                    let resDataStr = JSON.stringify(res.data);
                    let saveData = {
                        type: "article",
                        key: res.data.id,
                        value: resDataStr,
                        sort: _this.sortStatus + _this.timestamp,
                        keyword: ',[' + _this.catalogId + '],' + _this.setTitle + ','
                    };
                    //                1是置顶（默认倒序）  keyword ",[1],文章title,"
                    event.save(saveData, function (data) {
                        if (data.type == 'success') {
                            _this.deleteDraft('noclose');
                            //                                    event.closeURL();
                            _this.toSendArticle = false;
                            //                                    全局监听文章变动
                            let listenData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '文章改变', '');
                            event.sendGlobalEvent('onArticleChange', listenData);
                            event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('view/article/preview.js?articleId=' + res.data.id + '&publish=' + _this.publish), function (data) {
                                _this.currentPro = 0; //当前进度
                                _this.proTotal = 0; //总的进度
                                _this.processWidth = 0; //进度条宽度
                                //                                        if(!utils.isNull(data.data.isDone) && data.data.isDone == 'complete'){
                                let E = {
                                    isDone: 'complete'
                                };
                                let backData = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].message('success', '成功', E);
                                event.closeURL(backData);
                                //                                        }
                            });
                            //                                    event.router(utils.locate('view/article/preview.js?articleId=' + res.data.id + '&publish=' + _this.publish));
                        } else {
                            _this.toSendArticle = false;
                            _this.currentPro = 0; //当前进度
                            _this.proTotal = 0; //总的进度
                            _this.processWidth = 0; //进度条宽度
                            event.toast(data.content);
                        };
                    });
                } else {
                    event.toast(res.content);
                    _this.toSendArticle = false;
                    _this.currentPro = 0; //当前进度
                    _this.proTotal = 0; //总的进度
                    _this.processWidth = 0; //进度条宽度
                }
            }, function (err) {
                event.toast(err.content);
                _this.toSendArticle = false;
                _this.currentPro = 0; //当前进度
                _this.proTotal = 0; //总的进度
                _this.processWidth = 0; //进度条宽度
            });
        },

        //            点击"+"号里的文本时
        addTextPara: function (index) {
            var _this = this;
            event.openEditor('', function (data) {
                if (data.type == 'success' && data.data != '') {
                    let textImg = __WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('resources/images/text.png');
                    //                    将返回回来的html数据赋值进去
                    let newPara = {
                        //原图
                        paraImage: '',
                        //                                    小缩略图
                        thumbnailImage: textImg,
                        //                        paraText:_this.checkInput(data.data),
                        paraText: data.data,
                        mediaType: "image",
                        show: true,
                        //          对象id
                        id: 0,
                        //                                            第三方链接
                        url: ''
                    };
                    _this.paraList.splice(index, 0, newPara);
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                    if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                    }
                    //                    modal.toast({message:_this.paraList[index].paraText,duration:3});
                }
            });
        },
        //            点击"+"号里的图片时
        addImgPara: function (index) {
            var _this = this;
            album.openAlbumMuti(
            //选完图片后触发回调函数
            function (data) {
                if (data.type == 'success') {
                    //                    data.data里存放的是用户选取的图片路径
                    for (let i = 0; i < data.data.length; i++) {
                        let newPara = {
                            //原图
                            paraImage: data.data[i].originalPath,
                            //                                    小缩略图
                            thumbnailImage: data.data[i].thumbnailSmallPath,
                            paraText: '',
                            show: true,
                            mediaType: "image",
                            //          对象id
                            id: 0,
                            //                                            第三方链接
                            url: ''
                        };
                        _this.paraList.splice(index + i, 0, newPara);
                        _this.clearIconBox();
                        //                    添加修改标志
                        _this.hadChange = 1;
                        //                                if(utils.isNull(_this.articleId)){
                        //                        临时保存到缓存
                        _this.saveDraft();
                        //                                }
                    }
                }
            });
        },
        //            点击第一个"+"号时触发
        firstShow: function () {
            this.firstPlusShow = !this.firstPlusShow;
            if (lastIndex != -1) {
                setTimeout(() => {
                    if (this.paraList[lastIndex].show == false) {
                        this.paraList[lastIndex].show = true;
                    }
                    lastIndex = -1;
                }, 60);
            }
        },
        //            点击第2个以后的"+"号时，触发
        showIconBox: function (index) {
            setTimeout(() => {
                if (this.firstPlusShow == false) {
                    this.firstPlusShow = true;
                }
            }, 60);
            if (lastIndex == -1) {
                this.paraList[index].show = !this.paraList[index].show;
            } else {
                this.paraList[index].show = !this.paraList[index].show;
                //需要加延迟 否则画面会出现卡顿。先将点击的加号转变成功能盒，再将上一个功能后转变为"+"号
                setTimeout(() => {
                    if (this.paraList[lastIndex].show == false) {
                        this.paraList[lastIndex].show = true;
                    }
                }, 60);
            }
            setTimeout(() => {
                lastIndex = index;
            }, 60);
        },
        //            点击空白区域时，将功能盒子隐藏，显示出"+"号
        clearIconBox: function () {
            if (lastIndex != -1) {
                if (this.paraList[lastIndex].show == false) {
                    this.paraList[lastIndex].show = true;
                }
                lastIndex = -1;
            }
            if (this.firstPlusShow == false) {
                this.firstPlusShow = true;
            }
        },
        //            判断是否最后一个段落来添加向下移动的箭头。
        lastPara: function (index) {
            if (index != this.paraList.length - 1) {
                return true;
            } else {
                return false;
            }
        },
        //            上箭头
        moveUp: function (index) {
            let _this = this;
            this.firstPlusShow = true;
            if (lastIndex != -1) {
                this.paraList[lastIndex].show = true;
                lastIndex = -1;
            }
            //         方法2
            let a = this.paraList[index].thumbnailImage;
            let b = this.paraList[index].paraText;
            let c = this.paraList[index].mediaType;
            let d = this.paraList[index].paraImage;
            let e = this.paraList[index].id;
            let f = this.paraList[index].url;
            this.paraList[index].mediaType = this.paraList[index - 1].mediaType;
            this.paraList[index].thumbnailImage = this.paraList[index - 1].thumbnailImage;
            this.paraList[index].paraText = this.paraList[index - 1].paraText;
            this.paraList[index].paraImage = this.paraList[index - 1].paraImage;
            this.paraList[index].id = this.paraList[index - 1].id;
            this.paraList[index].url = this.paraList[index - 1].url;
            this.paraList[index - 1].thumbnailImage = a;
            this.paraList[index - 1].paraText = b;
            this.paraList[index - 1].mediaType = c;
            this.paraList[index - 1].paraImage = d;
            this.paraList[index - 1].id = e;
            this.paraList[index - 1].url = f;
            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.paraList[index].serveThumbnail)) {
                let g = this.paraList[index].serveThumbnail;
                this.paraList[index].serveThumbnail = this.paraList[index - 1].serveThumbnail;
                this.paraList[index - 1].paraImage = g;
            }
            //                    添加修改标志
            this.hadChange = 1;
            //                if(utils.isNull(_this.articleId)){
            //                        临时保存到缓存
            this.saveDraft();
            //                }
        },
        //            下箭头
        moveBottom: function (index) {
            let _this = this;
            this.firstPlusShow = true;
            if (lastIndex != -1) {
                this.paraList[lastIndex].show = true;
                lastIndex = -1;
            }
            //         方法2
            let a = this.paraList[index].thumbnailImage;
            let b = this.paraList[index].paraText;
            let c = this.paraList[index].mediaType;
            let d = this.paraList[index].paraImage;
            let e = this.paraList[index].id;
            let f = this.paraList[index].url;
            this.paraList[index].mediaType = this.paraList[index + 1].mediaType;
            this.paraList[index].thumbnailImage = this.paraList[index + 1].thumbnailImage;
            this.paraList[index].paraText = this.paraList[index + 1].paraText;
            this.paraList[index].paraImage = this.paraList[index + 1].paraImage;
            this.paraList[index].id = this.paraList[index + 1].id;
            this.paraList[index].url = this.paraList[index + 1].url;
            this.paraList[index + 1].thumbnailImage = a;
            this.paraList[index + 1].paraText = b;
            this.paraList[index + 1].mediaType = c;
            this.paraList[index + 1].paraImage = d;
            this.paraList[index + 1].id = e;
            this.paraList[index + 1].url = f;
            if (!__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(this.paraList[index].serveThumbnail)) {
                let g = this.paraList[index].serveThumbnail;
                this.paraList[index].serveThumbnail = this.paraList[index + 1].serveThumbnail;
                this.paraList[index + 1].paraImage = g;
            }
            //                    添加修改标志
            this.hadChange = 1;
            //                if(utils.isNull(_this.articleId)){
            //                        临时保存到缓存
            this.saveDraft();
            //                }
        },
        //            用户执行删除时触发询问。
        showConfirm: function (index) {
            var _this = this;
            var imageNum = 0;
            //                判断至少要保留一张图;
            if (_this.paraList[index].mediaType == 'image' && _this.paraList[index].paraImage != '') {
                //判断是不是图片
                _this.paraList.forEach(function (item) {
                    if ((item.mediaType == 'image' || item.mediaType == 'product') && item.paraImage != '') {
                        imageNum++;
                    }
                });
                if (imageNum <= 1) {
                    //                        modal.toast({message: '至少要保留一张图片', duration: 0.5});
                    event.toast('至少要保留一张图片');
                    return;
                }
            }
            modal.confirm({
                message: '确定删除该段?',
                okTitle: '确定',
                cancelTitle: '取消',
                duration: 0.3
            }, function (value) {
                if (value == '确定') {
                    //    将内容删掉
                    _this.paraList.splice(index, 1);
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            删除投票
        closeVote: function (index) {
            var _this = this;
            modal.confirm({
                message: '确定删除投票?',
                okTitle: '删除',
                cancelTitle: '取消',
                duration: 0.3
            }, function (value) {
                console.log(value);
                if (value == '删除') {
                    //                将内容删掉
                    _this.voteList.splice(index, 1);
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            编辑段落图片或者视频
        editParaImage(imgSrc, index, mediaType) {
            var _this = this;
            //                if(mediaType == 'product'){
            //                    event.openURL(utils.locate('view/shop/goods/manage.js?from=editor'),function (data) {
            //                        if (data.type == 'success') {
            //                            _this.paraList[index].paraImage = data.data.thumbnail;
            //                            _this.paraList[index].thumbnailImage = data.data.thumbnail;
            //                            _this.paraList[index].paraText = data.data.name;
            ////                    添加修改标志
            //                            _this.hadChange = 1;
            ////                        if(utils.isNull(_this.articleId)){
            ////                        临时保存到缓存
            //                            _this.saveDraft();
            ////                        }
            //                        }
            //                    })
            //                    return;
            //                }
            //                判断是否没有图片
            if (__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].isNull(imgSrc)) {
                album.openAlbumSingle(false, function (data) {
                    _this.paraList[index].paraImage = data.data.originalPath;
                    _this.paraList[index].thumbnailImage = data.data.thumbnailSmallPath;
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                });
                return;
            } else {
                //                    modal.confirm({
                //                        message: '请选择裁剪或者更换图片',
                //                        duration: 0.3,
                //                        okTitle:'裁剪',
                //                        cancelTitle:'更换',
                //                    }, function (value) {
                //                        event.toast(value);
                //                        if(value == '更换'){
                ////                                调用单选图片接口
                //                            album.openAlbumSingle(false, function(data){
                //                                _this.paraList[index].paraImage ='file:/' + data.data.originalPath;
                //                                _this.paraList[index].thumbnailImage ='file:/' + data.data.thumbnailSmallPath;
                //                            })
                //                        }else if(value == '裁剪'){
                if (mediaType == 'image' || mediaType == 'product') {
                    //                                调用裁剪图片
                    album.openCrop(imgSrc, function (data) {
                        //                            utils.debug(data);
                        if (data.type == 'success') {
                            _this.paraList[index].paraImage = data.data.originalPath;
                            _this.paraList[index].thumbnailImage = data.data.thumbnailSmallPath;
                            //                    添加修改标志
                            _this.hadChange = 1;
                            //                                if(utils.isNull(_this.articleId)){
                            //                        临时保存到缓存
                            _this.saveDraft();
                            //                                }
                        } else {
                            if (data.content == '用户取消') {} else {
                                event.toast(data.content);
                            }
                        }
                    });
                } else if (mediaType == 'video') {
                    album.openVideo(function (data) {
                        if (data.type == 'success') {
                            _this.paraList[index].paraImage = data.data.videoPath;
                            _this.paraList[index].thumbnailImage = data.data.coverImagePath;
                            //                    添加修改标志
                            _this.hadChange = 1;
                            //                                if(utils.isNull(_this.articleId)){
                            //                        临时保存到缓存
                            _this.saveDraft();
                            //                                }
                        } else {
                            if (data.content == '用户取消') {} else {
                                event.toast(data.content);
                            }
                        }
                    });
                }
                //                        }else{
                //                            event.toast(value);
                //                        }
                //                    })
            }
        },
        //            下拉刷新
        onrefresh(event) {
            console.log('is refreshing');
            this.refreshing = true;
            setTimeout(() => {
                this.refreshing = false;
            }, 10);
        },
        //            正在下拉
        onpullingdown(event) {
            console.log('is onpulling down');
        },
        //            跳转封面页面
        goCover: function () {
            //                event.openURL('file://assets/member/editor/cover.js');
            var _this = this;
            let paraLength = _this.paraList.length;
            var uploadLength = 0;
            let imgList = [];
            //                控制最多只传6张图
            for (let i = 0; i < paraLength; i++) {
                if (uploadLength < 6) {
                    //                        区分字体 图像 视频
                    if (_this.paraList[i].paraImage != '' && _this.paraList[i].mediaType == 'image') {
                        imgList.push({
                            path: _this.paraList[i].paraImage
                        });
                        uploadLength++;
                    } else if (_this.paraList[i].paraImage != '' && _this.paraList[i].mediaType == 'video') {
                        imgList.push({
                            path: _this.paraList[i].thumbnailImage
                        });
                        uploadLength++;
                    }
                }
            }
            var coverData = {
                image: imgList,
                cover: _this.coverImage
            };
            coverData = JSON.stringify(coverData);
            storage.setItem('coverImage', coverData);
            event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('view/member/editor/cover.js?name=coverImage'), function (message) {
                //                event.openURL('http://192.168.2.157:8081/cover.weex.js?name=coverImage',function (message) {
                //                    let jsonData = JSON.parse(data);
                //                    modal.toast({message:message,duration:1});
                if (message.type == 'success' && message.data != '') {
                    _this.coverImage = message.data;
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            跳转音乐页面
        goMusic: function () {
            //                event.openURL('file://assets/member/editor/music.js');
            let _this = this;
            //                event.toast(musicId);
            event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('view/member/editor/music.js?musicId=' + musicId), function (message) {
                //                event.openURL('http://192.168.2.157:8081/music.weex.js?musicId=' + musicId,function (message) {
                //                    event.toast(message);
                //                    let jsonData = JSON.parse(data);
                //                    modal.toast({message:message,duration:1});
                if (message.type == 'success' && message.data != '') {
                    _this.musicName = message.data.chooseMusicName;
                    musicId = message.data.chooseMusicId;
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            跳转投票页面
        goVote: function () {
            let _this = this;
            //                event.openURL('http://192.168.2.157:8081/vote.weex.js',function (message) {
            event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('view/member/editor/vote.js'), function (message) {
                if (message.type == 'success' && message.data != '') {
                    _this.voteList.push(message.data);
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            编辑投票
        editVote: function (index) {
            let _this = this;
            let voteData = JSON.stringify(_this.voteList[index]);
            storage.setItem('voteData', voteData);
            //                event.openURL('http://192.168.2.157:8081/vote.weex.js?name=voteData',function (message) {
            event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('view/member/editor/vote.js?name=voteData'), function (message) {
                if (message.type == 'success' && message.data != '') {
                    //                        直接=无法重新渲染页面。需要push后才可以
                    //                        _this.voteList[index] = message.data;
                    _this.voteList.splice(index, 1);
                    _this.voteList.splice(index, 0, message.data);
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            点击加号里的添加视频
        addVideoPara: function (index) {
            let _this = this;
            album.openVideo(function (data) {
                if (data.type == 'success') {
                    //                    data.data里存放的是用户选取的图片路径
                    let newPara = {
                        //原图
                        //                                    paraImage: data.data[i].originalPath,
                        paraImage: data.data.videoPath,
                        //                                    小缩略图
                        //                                    thumbnailImage: data.data[i].thumbnailSmallPath,
                        thumbnailImage: data.data.coverImagePath,
                        mediaType: "video",
                        paraText: '',
                        show: true,
                        //                             对象ID
                        id: 0,
                        //                            第三方链接
                        url: ''
                        //                          serveThumbnail:''
                    };
                    _this.paraList.splice(index, 0, newPara);
                    _this.clearIconBox();

                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        //            点击加号里的添加链接
        addLinkPara: function (index) {
            let _this = this;
            event.openURL(__WEBPACK_IMPORTED_MODULE_2__assets_utils__["a" /* default */].locate('view/shop/goods/manage.js?from=editor'), function (data) {
                if (data.type == 'success') {
                    let newPara = {
                        //原图
                        //                                    paraImage: data.data[i].originalPath,
                        paraImage: data.data.thumbnail,
                        //                                    小缩略图
                        //                                    thumbnailImage: data.data[i].thumbnailSmallPath,
                        thumbnailImage: data.data.thumbnail,
                        mediaType: "product",
                        paraText: '',
                        show: true,
                        //                             对象ID
                        id: data.data.id,
                        //                            第三方链接
                        url: ''
                        //                          serveThumbnail:''
                    };
                    _this.paraList.splice(index, 0, newPara);
                    _this.clearIconBox();
                    //                    添加修改标志
                    _this.hadChange = 1;
                    //                        if(utils.isNull(_this.articleId)){
                    //                        临时保存到缓存
                    _this.saveDraft();
                    //                        }
                }
            });
        },
        maskClick() {
            return;
        }
    }
});

/***/ }),

/***/ 3:
/***/ (function(module, exports) {

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  scopeId,
  cssModules
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  // inject cssModules
  if (cssModules) {
    var computed = options.computed || (options.computed = {})
    Object.keys(cssModules).forEach(function (key) {
      var module = cssModules[key]
      computed[key] = function () { return module }
    })
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),

/***/ 302:
/***/ (function(module, exports, __webpack_require__) {

var App = __webpack_require__(118);
App.el = '#root';
new Vue(App);

/***/ }),

/***/ 4:
/***/ (function(module, exports) {

/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
module.exports = function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}


/***/ }),

/***/ 5:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = POST;
/* harmony export (immutable) */ __webpack_exports__["a"] = GET;
/* harmony export (immutable) */ __webpack_exports__["c"] = SCAN;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_js__ = __webpack_require__(2);
const stream = weex.requireModule('stream');
const modal = weex.requireModule('modal');
const baseURL = '';

const event = weex.requireModule('event');
function POST(path, body) {
    return new Promise((resolve, reject) => {
        stream.fetch({
            method: 'POST',
            url: `${baseURL}${path}`,
            type: 'json',
            body: `${body}`
        }, response => {
            if (response.status == 200) {
                resolve(response.data);
            } else {
                reject({
                    type: "error",
                    content: "网络不稳定"
                });
            }
        }, () => {});
    });
}

function GET(path, resolve, reject) {
    // let cacheParams = {
    //     type:'httpCache',//类型
    //     key:`${baseURL}${path}`,//关键址
    // }
    // event.find(cacheParams,function (cache) {
    //    if (cache.type=='success') {
    //        if (cache.data != '') {
    //            resolve(JSON.parse(cache.data.value));
    //        }
    //    }
    // })
    stream.fetch({
        method: 'GET',
        url: `${baseURL}${path}`,
        type: 'json'
    }, response => {
        //请求 type=success 或 warn 或 error（没缓存） 时返回，都能正常获取数据
        if (response.status == 200) {
            resolve(response.data);
        } else
            //请求 type= error 网络正常，但服务器返回错误，有缓存，也需要给数据，并提示出错了  statusText=服务器返回的 content
            //网络异常，有缓存，需要给出缓存数据，并且   statusText 固定为 "网络不稳定"
            if (response.status == 304) {
                resolve(response.data);
                reject({
                    type: "error",
                    content: response.statusText
                });
            } else
                //网络异常，没有缓存
                {
                    reject({
                        type: "error",
                        content: '网络不稳定'
                    });
                }
    }, () => {});
}
//二维码扫描
function SCAN(message, resolve, reject) {
    if (message.type == 'success') {
        __WEBPACK_IMPORTED_MODULE_0__utils_js__["a" /* default */].readScan(message.data, function (data) {
            if (data.type == 'success') {
                if (data.data.type == '865380') {
                    let userId = parseInt(data.data.code) - 10200;
                    POST('weex/member/friends/add.jhtml?friendId=' + userId).then(function (mes) {
                        if (mes.type == "success") {
                            event.toast('添加好友请求已发送,请等待对方验证');
                        } else {
                            event.toast(mes.content);
                        }
                        resolve(mes);
                    }, function (err) {
                        reject(err);
                        event.toast(err.content);
                    });
                } else if (data.data.type == '818803') {
                    GET('weex/member/couponCode/use.jhtml?code=' + data.data.code, function (mes) {
                        modal.alert({
                            message: mes.content,
                            duration: 0.3
                        }, function (value) {});
                    }, function (err) {
                        event.toast(err.content);
                    });
                } else if (data.data.type == 'webView') {
                    event.openURL(message.data, function () {});
                } else {
                    event.toast('无效验证码');
                }
            } else {
                event.toast(data.content);
            }
        });
    } else {}
}

/***/ }),

/***/ 501:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.border {\n  border-style: solid;\n  border-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr20 {\n  margin-right: 20px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  border-bottom-width: 1px;\n  border-bottom-style: solid;\n  border-color: #ccc;\n  background-color: #EB4E40;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #EB4E40;\n  border-color: #EB4E40;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #EB4E40;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #EB4E40;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #EB4E40;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #EB4E40;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #EB4E40;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #EB4E40;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #EB4E40;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #EB4E40;\n}\n.button:disabled {\n  background-color: #EB4E40;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #EB4E40;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.5;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  background-color: #fff;\n  border-radius: 20px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n", ""]);

// exports


/***/ }),

/***/ 502:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.videoIconBox[data-v-88a2200a]{\n    position: absolute;\n    left: 0;\n    top:0;\n    width: 155px;\n    height: 155px;\n    background-color: rgba(136,136,136,0.3);\n}\n.goodsIcon[data-v-88a2200a]{\n    color: #fff;\n    font-size: 80px;\n    position:absolute;\n    top:37.5px;\n    left:37.5px;\n}\n.videoIcon[data-v-88a2200a]{\n    color: #fff;\n    font-size: 70px;\n    position:absolute;\n    top:42.5px;\n    left:42.5px;\n}\n.addIconBox[data-v-88a2200a]:active{\n    background-color: #ccc;\n}\n.processTotal[data-v-88a2200a]{\n    position: absolute;\n    bottom: 40px;\n    right: 50px;\n    font-size: 28px;\n    color: #888;\n}\n.processBg[data-v-88a2200a]{\n    background-color: #ccc;\n    width:500px;\n}\n.processStyle[data-v-88a2200a]{\n    height:10px;\n    position: absolute;\n    left: 50px;\n    bottom:100px;\n}\n.processText[data-v-88a2200a]{\n    position: absolute;\n    top:40px;\n    left: 50px;\n    font-size: 32px;\n}\n.processBox[data-v-88a2200a]{\n    height:250px;\n    border-radius: 5px;\n    width:600px;\n    background-color: #fff;\n    justify-content: space-between;\n}\n.sendMask[data-v-88a2200a]{\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    left:0;\n    right: 0;\n    background-color: rgba(0,0,0,0.8);\n    align-items: center;\n    justify-content: center;\n}\n.voteMargin[data-v-88a2200a]{\n    margin-bottom: 15px;\n}\n.paraTransition-enter-active[data-v-88a2200a], .paraTransition-leave-active[data-v-88a2200a] {\n    transition: all 0.2s;\n}\n.paraTransition-leave-to[data-v-88a2200a]{\n    transform: translateX(300px);\n    opacity: 0;\n}\n.paraTransition-enter[data-v-88a2200a]{\n    transform: translateX(0px);\n    opacity: 1;\n}\n.addVoteIcon[data-v-88a2200a]{\n    font-size: 39px;\n    padding-top:3px;\n}\n.addVote[data-v-88a2200a]{\n    color: #A89F95;\n    font-size: 34px;\n    margin-left: 10px;\n}\n.flexRow[data-v-88a2200a]{\n    padding-top: 20px;\n    padding-bottom: 20px;\n    justify-content: center;\n}\n.greyColor[data-v-88a2200a]{\n    color: #999;\n}\n.emptyBox[data-v-88a2200a]{\n    height:40px;\n}\n.arrowSize[data-v-88a2200a]{\n    color: #999;\n    font-size: 34px;\n    font-weight: 700;\n}\n.upArrow[data-v-88a2200a]{\n    top:0px;\n    padding-top: 5px;\n    padding-left: 10px;\n    padding-bottom: 10px;\n}\n.downArrow[data-v-88a2200a]{\n    bottom:0px;\n    padding-top: 10px;\n    padding-bottom: 5px;\n    padding-left: 10px;\n}\n.rightArrow[data-v-88a2200a]{\n    position: absolute;\n    right: 0px;\n    padding-right: 10px;\n}\n.paraClose[data-v-88a2200a]{\n    position: absolute;\n    top:0px;\n    left:0px;\n    padding-left: 5px;\n    padding-top: 5px;\n    padding-right: 5px;\n    padding-bottom: 5px;\n}\n.paraCloseSize[data-v-88a2200a]{\n    color: #999;\n    font-size: 34px;\n}\n.paraTextSize[data-v-88a2200a]{\n    font-size: 32px;\n    line-height:38px;\n    color: #444;\n    lines:4;\n    text-overflow: ellipsis;\n}\n.paraText[data-v-88a2200a]{\n    margin-left: 20px;\n    /*background-color: red;*/\n    width:445px;\n}\n.paraImage[data-v-88a2200a]{\n    width:155px;\n    height:155px;\n    border-radius: 10px;\n}\n.paraBoxHeight[data-v-88a2200a]{\n    height:225px;\n}\n.paraBox[data-v-88a2200a]{\n    flex-direction: row;\n    padding-left: 35px;\n    padding-right: 35px;\n    padding-top: 35px;\n    padding-bottom: 35px;\n    width:700px;\n    margin-left: 25px;\n    background-color: #fff;\n    border-bottom-right-radius: 20px;\n    border-top-right-radius: 20px;\n    border-bottom-left-radius: 20px;\n    border-top-left-radius: 20px;\n}\n.wrapperBox[data-v-88a2200a]{\n    background-color: #EFF0F5;\n}\n.addText[data-v-88a2200a]{\n    color: #FFE394;\n}\n.addImage[data-v-88a2200a]{\n    color: #1E7DEB;\n}\n.addVideo[data-v-88a2200a]{\n    color: #CCA7FC;\n}\n.addLinkPt[data-v-88a2200a]{\n    padding-top: 12px;\n}\n.addLink[data-v-88a2200a]{\n    color: #d81e06;\n    font-size: 44px;\n}\n.iconSize[data-v-88a2200a]{\n    font-size: 38px;\n}\n.addIconBox[data-v-88a2200a]{\n    padding-top: 15px;\n    padding-bottom: 15px;\n    padding-right:40px;\n    padding-left: 40px;\n}\n.iconBox[data-v-88a2200a]{\n    flex-direction: row;\n    background-color: #fff;\n    border-bottom-right-radius: 20px;\n    border-top-right-radius: 20px;\n    border-bottom-left-radius: 20px;\n    border-top-left-radius: 20px;\n    margin-top:15px;\n    margin-bottom:15px;\n}\n.plusSign[data-v-88a2200a]{\n    padding-left: 12px;\n    padding-right: 12px;\n    padding-top: 1px;\n    padding-bottom: 1px;\n    background-color:#D7DBD5;\n    color: #fff;\n    border-style: solid;\n    border-width: 1px;\n    border-color: rgba(133,133,133,0.2);\n    border-radius: 30px;\n    font-size: 30px;\n    font-weight: 700;\n}\n.plusSignBox[data-v-88a2200a]{\n    padding-left:15px;\n    padding-right: 15px;\n    padding-bottom:15px;\n    padding-top: 15px;\n}\n.addBox[data-v-88a2200a]{\n    align-items: center;\n    justify-content: center;\n    /*padding-top: 15px;*/\n    /*padding-bottom: 15px;*/\n}\n.setTitle[data-v-88a2200a]{\n    position: absolute;\n    top:40px;\n    color: #fff;\n    font-size: 40px;\n    left: 25px;\n    right:25px;\n}\n.musicSize[data-v-88a2200a]{\n    color: #666;\n    font-size: 27px;\n}\n.bottomBtn[data-v-88a2200a]{\n    position: absolute;\n    bottom: 20px;\n    border-radius: 10px;\n    color: #666;\n    padding-bottom: 5px;\n    justify-content: center;\n    padding-right: 12px;\n    padding-left: 12px;\n    padding-top: 5px;\n    background-color: #fff;\n}\n.addMusic[data-v-88a2200a]{\n    left: 25px;\n    max-width: 500px\n}\n.editCover[data-v-88a2200a]{\n    right: 25px;\n}\n.coverMaskImage[data-v-88a2200a]{\n    position: absolute;\n    top:0;\n    left:0;\n    width:750px;\n    height:375px;\n    background-color: #888;\n    opacity: 0.5;\n}\n.coverImage[data-v-88a2200a]{\n    width:750px;\n    height:375px;\n}\n", ""]);

// exports


/***/ }),

/***/ 6:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__assets_utils__ = __webpack_require__(2);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
    props: {
        title: { default: "navbar" },
        complete: { default: '' },
        showComplete: { default: true },
        border: { default: true }
    },
    methods: {
        classHeader: function () {
            let dc = __WEBPACK_IMPORTED_MODULE_0__assets_utils__["a" /* default */].device();

            return dc;
        },
        goback: function (e) {
            this.$emit('goback');
        },
        goComplete: function (e) {
            this.$emit('goComplete');
        }
    }
});

/***/ }),

/***/ 617:
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('navbar', {
    attrs: {
      "title": _vm.title,
      "complete": _vm.complete
    },
    on: {
      "goback": _vm.goBack,
      "goComplete": _vm.goComplete
    }
  }), _vm._v(" "), _c('list', {
    staticClass: "wrapperBox"
  }, [_c('cell', [_c('div', [_c('image', {
    staticClass: "coverImage",
    attrs: {
      "resize": "cover",
      "src": _vm.coverImage
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "coverMaskImage"
  }), _vm._v(" "), _c('text', {
    staticClass: "setTitle",
    on: {
      "trigger": function($event) {
        _vm.articleTitle(_vm.setTitle)
      },
      "click": function($event) {
        _vm.articleTitle(_vm.setTitle)
      }
    }
  }, [_vm._v(_vm._s(_vm.setTitle))]), _vm._v(" "), _c('div', {
    staticClass: "bottomBtn addMusic"
  }, [(this.musicName == '') ? _c('text', {
    staticClass: "musicSize",
    on: {
      "click": function($event) {
        _vm.goMusic()
      }
    }
  }, [_vm._v(_vm._s(_vm.addMusic))]) : _c('text', {
    staticClass: "musicSize",
    style: ({
      fontFamily: 'iconfont'
    }),
    on: {
      "click": function($event) {
        _vm.goMusic()
      }
    }
  }, [_vm._v(" " + _vm._s(_vm.musicName))])]), _vm._v(" "), _c('text', {
    staticClass: "bottomBtn editCover musicSize",
    on: {
      "click": function($event) {
        _vm.goCover()
      }
    }
  }, [_vm._v("编辑封面")])])]), _vm._v(" "), _c('cell', [_c('div', {
    staticClass: "addBox",
    on: {
      "click": function($event) {
        _vm.clearIconBox()
      }
    }
  }, [(_vm.firstPlusShow) ? _c('div', [_c('div', {
    staticClass: "plusSignBox",
    on: {
      "click": function($event) {
        _vm.firstShow()
      }
    }
  }, [_c('text', {
    staticClass: "plusSign",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])])]) : _c('div', {
    staticClass: "iconBox"
  }, [_c('div', {
    staticClass: "addIconBox ",
    on: {
      "click": function($event) {
        _vm.addTextPara(0)
      }
    }
  }, [_c('text', {
    staticClass: "addText iconSize",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "addIconBox ",
    on: {
      "click": function($event) {
        _vm.addImgPara(0)
      }
    }
  }, [_c('text', {
    staticClass: "addImage iconSize",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "addIconBox ",
    on: {
      "click": function($event) {
        _vm.addVideoPara(0)
      }
    }
  }, [_c('text', {
    staticClass: "addVideo iconSize",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "addIconBox addLinkPt",
    on: {
      "click": function($event) {
        _vm.addLinkPara(0)
      }
    }
  }, [_c('text', {
    staticClass: " iconSize addLink",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")])])])])]), _vm._v(" "), _c('cell', [_c('transition-group', {
    attrs: {
      "name": "paraTransition",
      "tag": "div"
    }
  }, _vm._l((_vm.paraList), function(item, index) {
    return _c('div', {
      key: item
    }, [_c('div', {
      staticClass: "paraBox paraBoxHeight"
    }, [_c('div', {
      staticClass: "paraClose",
      on: {
        "click": function($event) {
          _vm.showConfirm(index)
        }
      }
    }, [_c('text', {
      staticClass: "paraCloseSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]), _vm._v(" "), (index != 0) ? _c('div', {
      staticClass: "rightArrow upArrow",
      on: {
        "click": function($event) {
          _vm.moveUp(index)
        }
      }
    }, [_c('text', {
      staticClass: "arrowSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), (_vm.lastPara(index)) ? _c('div', {
      staticClass: "rightArrow downArrow",
      on: {
        "click": function($event) {
          _vm.moveBottom(index)
        }
      }
    }, [_c('text', {
      staticClass: "arrowSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), _c('div', {
      on: {
        "click": function($event) {
          _vm.editParaImage(item.paraImage, index, item.mediaType)
        }
      }
    }, [_c('image', {
      staticClass: "paraImage",
      attrs: {
        "resize": "cover",
        "src": _vm._f("watchThumbImg")(item.thumbnailImage)
      }
    }), _vm._v(" "), (item.mediaType == 'video') ? _c('div', {
      staticClass: "videoIconBox"
    }, [_c('text', {
      staticClass: "videoIcon",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), (item.mediaType == 'product') ? _c('div', {
      staticClass: "videoIconBox"
    }, [_c('text', {
      staticClass: "videoIcon goodsIcon",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]) : _vm._e()]), _vm._v(" "), _c('div', {
      staticClass: "paraText",
      on: {
        "click": function($event) {
          _vm.editorText(index)
        }
      }
    }, [(item.paraText != '' && item.paraText != null && item.paraText != undefined && item.paraText != 'undefined') ? _c('text', {
      staticClass: "paraTextSize"
    }, [_vm._v(_vm._s(_vm._f("htmlDeal")(item.paraText)))]) : _c('text', {
      staticClass: "paraTextSize greyColor"
    }, [_vm._v("点击添加文字")])])]), _vm._v(" "), _c('div', {
      staticClass: "addBox",
      on: {
        "click": function($event) {
          _vm.clearIconBox()
        }
      }
    }, [(item.show) ? _c('div', [_c('div', {
      staticClass: "plusSignBox",
      on: {
        "click": function($event) {
          _vm.showIconBox(index)
        }
      }
    }, [_c('text', {
      staticClass: "plusSign",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])])]) : _c('div', {
      staticClass: "iconBox"
    }, [_c('div', {
      staticClass: "addIconBox ",
      on: {
        "click": function($event) {
          _vm.addTextPara(index + 1)
        }
      }
    }, [_c('text', {
      staticClass: "addText iconSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]), _vm._v(" "), _c('div', {
      staticClass: "addIconBox ",
      on: {
        "click": function($event) {
          _vm.addImgPara(index + 1)
        }
      }
    }, [_c('text', {
      staticClass: "addImage iconSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]), _vm._v(" "), _c('div', {
      staticClass: "addIconBox ",
      on: {
        "click": function($event) {
          _vm.addVideoPara(index + 1)
        }
      }
    }, [_c('text', {
      staticClass: "addVideo iconSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]), _vm._v(" "), _c('div', {
      staticClass: "addIconBox addLinkPt",
      on: {
        "click": function($event) {
          _vm.addLinkPara(index + 1)
        }
      }
    }, [_c('text', {
      staticClass: " iconSize addLink",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])])])])])
  }))], 1), _vm._v(" "), _c('cell', [_vm._l((_vm.voteList), function(item, index) {
    return _c('div', {
      staticClass: "voteMargin",
      on: {
        "click": function($event) {
          _vm.editVote(index)
        }
      }
    }, [_c('div', {
      staticClass: "paraBox paraBoxHeight"
    }, [_c('div', {
      staticClass: "paraClose",
      on: {
        "click": function($event) {
          _vm.closeVote(index)
        }
      }
    }, [_c('text', {
      staticClass: "paraCloseSize",
      style: ({
        fontFamily: 'iconfont'
      })
    }, [_vm._v("")])]), _vm._v(" "), _c('div', [_c('image', {
      staticClass: "paraImage",
      attrs: {
        "src": _vm.voteImg
      }
    })]), _vm._v(" "), _c('div', {
      staticClass: "paraText"
    }, [_c('text', {
      staticClass: "paraTextSize"
    }, [_vm._v(_vm._s(item.textAreaTitle))])])])])
  }), _vm._v(" "), _c('div', {
    staticClass: "paraBox flexRow ",
    on: {
      "click": function($event) {
        _vm.addLinkPara(_vm.paraList.length)
      }
    }
  }, [_c('text', {
    staticClass: "addVote addVoteIcon ",
    style: ({
      fontFamily: 'iconfont'
    })
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "addVote"
  }, [_vm._v("添加商品")])])], 2), _vm._v(" "), _c('cell', [_c('div', {
    staticClass: "emptyBox"
  })])], 1), _vm._v(" "), (_vm.toSendArticle) ? _c('div', {
    staticClass: "sendMask",
    on: {
      "click": function($event) {
        _vm.maskClick()
      }
    }
  }, [_c('div', {
    staticClass: "processBox"
  }, [_c('text', {
    staticClass: "processText"
  }, [_vm._v("正在云同步,请稍候...")]), _vm._v(" "), _c('div', {
    staticClass: "processStyle processBg"
  }), _vm._v(" "), _c('div', {
    staticClass: "processStyle bkg-primary",
    style: ({
      width: _vm.processWidth + 'px'
    })
  }), _vm._v(" "), _c('text', {
    staticClass: "processTotal"
  }, [_vm._v(_vm._s(_vm.currentPro) + "/" + _vm._s(_vm.proTotal))])])]) : _vm._e()], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-88a2200a", module.exports)
  }
}

/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/**每个页面都必须的，墙纸**/\n.wrapper {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 750px;\n  background-color: #eee;\n}\n/**默认标题字体**/\n.nav_title {\n  font-size: 38px;\n  color: #fff;\n  line-height: 38px;\n}\n.title {\n  font-size: 32px;\n  color: #000;\n}\n/**默认子标题字体**/\n.sub_title {\n  font-size: 30px;\n  color: #999;\n}\n.sub_date {\n  font-size: 26px;\n  color: #999;\n}\n.fz28 {\n  font-size: 28px;\n}\n.fz30 {\n  font-size: 30px;\n}\n.fz32 {\n  font-size: 32px;\n}\n.fz35 {\n  font-size: 35px;\n}\n.fz40 {\n  font-size: 40px;\n}\n.boder-bottom {\n  border-style: solid;\n  border-bottom-width: 1px;\n  border-color: #ccc;\n}\n.boder-top {\n  border-style: solid;\n  border-top-width: 1px;\n  border-color: #ccc;\n}\n.boder-right {\n  border-style: solid;\n  border-right-width: 1px;\n  border-color: #ccc;\n}\n.boder-left {\n  border-style: solid;\n  border-left-width: 1px;\n  border-color: #ccc;\n}\n.border {\n  border-style: solid;\n  border-width: 1px;\n  border-color: #ccc;\n}\n.pl10 {\n  padding-left: 10px;\n}\n.pt10 {\n  padding-top: 10px;\n}\n.pt15 {\n  padding-top: 15px;\n}\n.pb10 {\n  padding-bottom: 10px;\n}\n.pl20 {\n  padding-left: 20px;\n}\n.pt20 {\n  padding-top: 20px;\n}\n.pb15 {\n  padding-bottom: 15px;\n}\n.pb20 {\n  padding-bottom: 20px;\n}\n.pt25 {\n  padding-top: 25px;\n}\n.pt30 {\n  padding-top: 30px;\n}\n.pt40 {\n  padding-top: 40px;\n}\n.pb40 {\n  padding-bottom: 40px;\n}\n.pb30 {\n  padding-bottom: 30px;\n}\n.pb25 {\n  padding-bottom: 25px;\n}\n.pl25 {\n  padding-left: 25px;\n}\n.pl30 {\n  padding-left: 30px;\n}\n.pr10 {\n  padding-right: 10px;\n}\n.pr20 {\n  padding-right: 20px;\n}\n.pr25 {\n  padding-right: 25px;\n}\n.pr30 {\n  padding-right: 30px;\n}\n.pl35 {\n  padding-left: 35px;\n}\n.pr35 {\n  padding-right: 35px;\n}\n.bgWhite {\n  background-color: #ffffff;\n}\n.textActive:active {\n  background-color: #ccc;\n}\n/**top 大小**/\n.mt0 {\n  margin-top: 0px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.mt20 {\n  margin-top: 20px;\n}\n.mt30 {\n  margin-top: 30px;\n}\n.mt50 {\n  margin-top: 50px;\n}\n/**bottom 大小**/\n.bt0 {\n  margin-bottom: 0px;\n}\n.bt5 {\n  margin-bottom: 5px;\n}\n.bt10 {\n  margin-bottom: 10px;\n}\n.bt15 {\n  margin-bottom: 15px;\n}\n.bt20 {\n  margin-bottom: 20px;\n}\n.bt30 {\n  margin-bottom: 30px;\n}\n.bt50 {\n  margin-bottom: 50px;\n}\n.mr5 {\n  margin-right: 5px;\n}\n.mr20 {\n  margin-right: 20px;\n}\n.mr30 {\n  margin-right: 30px;\n}\n/**left 大小**/\n.ml5 {\n  margin-left: 5px;\n}\n.ml10 {\n  margin-left: 10px;\n}\n.ml20 {\n  margin-left: 20px;\n}\n.ml30 {\n  margin-left: 30px;\n}\n.header {\n  height: 136px;\n  padding-top: 44px;\n  flex-direction: row;\n  position: sticky;\n  border-bottom-width: 1px;\n  border-bottom-style: solid;\n  border-color: #ccc;\n  background-color: #EB4E40;\n}\n.nav {\n  width: 654px;\n  justify-content: space-between;\n  flex-direction: row;\n  height: 92px;\n  align-items: center;\n  margin-top: 0px;\n}\n.nav_back {\n  margin-top: 0px;\n  flex-direction: row;\n  width: 92px;\n  height: 92px;\n  align-items: center;\n  justify-content: center;\n}\n.corpusActive {\n  color: #EB4E40;\n  border-color: #EB4E40;\n  border-style: solid;\n  border-bottom-width: 4px;\n}\n.footer {\n  position: fixed;\n  bottom: 0px;\n  left: 0px;\n  right: 0px;\n  height: 100px;\n}\n.fill {\n  height: 500px;\n  width: 750px;\n  background-color: #eee;\n}\n/** 图标图像 **/\n.iconImg {\n  width: 60px;\n  height: 60px;\n  font-size: 60px;\n}\n/**cell 分组头**/\n.cell-header {\n  height: 70px;\n  flex-direction: row;\n  background-color: #ddd;\n  padding-left: 20px;\n}\n/**cell 行**/\n.cell-row {\n  min-height: 100px;\n  flex-direction: column;\n  background-color: #ffffff;\n  padding-left: 20px;\n  margin-top: 20px;\n}\n.cell-row-row {\n  min-height: 100px;\n  flex-direction: row;\n  justify-content: space-between;\n  background-color: #ffffff;\n  padding-left: 20px;\n  padding-right: 20px;\n  align-items: center;\n  margin-top: 20px;\n}\n.cell-line {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.borderTop {\n  border-top-width: 1px;\n  border-top-color: #ccc;\n  border-top-style: solid;\n}\n.borderBottom {\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n/**cell 内面行**/\n.cell-panel {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: row;\n  align-items: center;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n}\n.cell-panel-column {\n  height: 98px;\n  min-height: 98px;\n  flex-direction: column;\n  justify-content: space-around;\n  border-bottom-width: 1px;\n  border-bottom-color: #ccc;\n  border-bottom-style: solid;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n.cell-panel-column :last-child {\n  border-bottom-width: 0px;\n}\n.cell-panel :last-child {\n  border-bottom-width: 0px;\n}\n.cell-bottom-clear {\n  border-bottom-width: 0px;\n}\n.cell-clear {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  border-top-width: 0px;\n  border-bottom-width: 0px;\n}\n/**两边对齐**/\n.space-between {\n  justify-content: space-between;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-start {\n  justify-content: flex-start;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-end {\n  justify-content: flex-end;\n  flex-direction: row;\n  align-items: center;\n}\n.flex-center {\n  justify-content: center;\n  flex-direction: row;\n  align-items: center;\n}\n.space-around {\n  justify-content: space-around;\n  flex-direction: row;\n  align-items: center;\n}\n/**横向部局居中对齐**/\n.flex-row {\n  flex-direction: row;\n  align-items: center;\n}\n.flex-column {\n  flex-direction: column;\n  align-items: center;\n}\n/**flex 部局比例**/\n.flex1 {\n  flex: 1;\n}\n.flex2 {\n  flex: 2;\n}\n.flex3 {\n  flex: 3;\n}\n.flex4 {\n  flex: 4;\n}\n.flex5 {\n  flex: 6;\n}\n.flex6 {\n  flex: 6;\n}\n/**常用背景颜色**/\n.bkg-white {\n  background-color: white;\n}\n.bkg-primary {\n  background-color: #EB4E40;\n}\n.bkg-gray {\n  background-color: #eee;\n}\n.bd-primary {\n  border-color: #EB4E40;\n}\n.bkg-delete {\n  background-color: red;\n}\n/**常用字体颜色**/\n.white {\n  color: white;\n}\n.primary {\n  color: #EB4E40;\n}\n.gray {\n  color: #999;\n}\n/**ico 字体大小与颜色**/\n.ico {\n  font-size: 48px;\n  color: #EB4E40;\n  margin-top: 2px;\n}\n.ico_big {\n  font-size: 72px;\n  color: #EB4E40;\n  margin-top: 4px;\n}\n.ico_small {\n  font-size: 32px;\n  color: #EB4E40;\n  margin-top: 1px;\n}\n/**右箭头 字体大小与颜色**/\n.arrow {\n  font-size: 32px;\n  color: #ccc;\n  width: 40px;\n}\n/**打勾 字体大小与颜色**/\n.check {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n}\n.shopCheck {\n  font-size: 32px;\n  color: #EB4E40;\n  width: 40px;\n  margin-left: 150px;\n}\n/**默认按钮类型**/\n.button {\n  font-size: 32px;\n  text-align: center;\n  color: #fff;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  background-color: #EB4E40;\n  border-radius: 15px;\n  height: 80px;\n  line-height: 50px;\n  align-items: center;\n  justify-content: center;\n}\n.button:active {\n  background-color: #ccc;\n  color: #EB4E40;\n}\n.button:disabled {\n  background-color: #EB4E40;\n  color: #999;\n}\n/**上拉刷新，下拉加载样式**/\n.refresh {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.loading {\n  flex-direction: column;\n  align-items: center;\n  padding-top: 10px;\n}\n.noLoading {\n  height: 999px;\n}\n.gif {\n  width: 50px;\n  height: 50px;\n}\n.indicator {\n  font-size: 36px;\n  color: #EB4E40;\n  width: 750px;\n  text-align: center;\n  margin-top: 20px;\n  margin-bottom: 20px;\n}\n/**超长用省略号**/\n.lines-ellipsis {\n  lines: 1;\n  text-overflow: ellipsis;\n}\n.V1 {\n  height: 146px;\n  padding-top: 54px;\n}\n.IPhoneX {\n  height: 156px;\n  padding-top: 64px;\n}\n.addTopV1 {\n  top: 54px;\n}\n.addTopIPhoneX {\n  top: 64px;\n}\n.addInfoV1 {\n  height: 430px;\n  padding-top: 50px;\n}\n.addInfoIPhoneX {\n  height: 440px;\n  padding-top: 60px;\n}\n.addBgImgV1 {\n  height: 430px;\n}\n.addBgImgIPhoneX {\n  height: 440px;\n}\n.hideCorpusV1 {\n  top: 146px;\n}\n.hideCorpusIPhoneX {\n  top: 156px;\n}\n.pageTopV1 {\n  top: 226px;\n}\n.pageTopIPhoneX {\n  top: 236px;\n}\n.maskLayer {\n  position: fixed;\n  top: 0px;\n  left: 0px;\n  right: 0px;\n  bottom: 0px;\n  background-color: #000;\n  opacity: 0.5;\n}\n.showBox {\n  position: fixed;\n  top: 150px;\n  right: 15px;\n  background-color: #fff;\n  border-radius: 20px;\n  padding-top: 20px;\n  padding-bottom: 20px;\n}\n.arrowUp {\n  position: fixed;\n  top: 148px;\n  right: 30px;\n}\n.refreshImg {\n  width: 60px;\n  height: 60px;\n  border-radius: 30px;\n}\n.refreshBox {\n  height: 120px;\n  width: 750px;\n  align-items: center;\n  justify-content: center;\n}\n.indexMtIPhoneX {\n  margin-top: 124px;\n}\n", ""]);

// exports


/***/ }),

/***/ 776:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(501);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("380c0e3b", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88a2200a!../../node_modules/_less-loader@4.0.5@less-loader/dist/cjs.js!./wx.less", function() {
     var newContent = require("!!../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88a2200a!../../node_modules/_less-loader@4.0.5@less-loader/dist/cjs.js!./wx.less");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 777:
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(502);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(1)("6f4a8606", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88a2200a&scoped=true!../../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./editor.vue", function() {
     var newContent = require("!!../../../../node_modules/_css-loader@0.26.4@css-loader/index.js!../../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/style-rewriter.js?id=data-v-88a2200a&scoped=true!../../../../node_modules/_vue-loader@10.3.0@vue-loader/lib/selector.js?type=styles&index=1!./editor.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.cb[data-v-019a21a0] {\n    border-bottom-width: 0px;\n}\n.navRightBox[data-v-019a21a0]{\n    min-width: 92px;\n    height: 92px;\n    align-items: center;\n    justify-content: center;\n}\n.nav_bg[data-v-019a21a0] {\n    width:750px;\n    height: 156px;\n    background-size: cover;\n    position: absolute;\n    top:0;\n}\n.nav_ico[data-v-019a21a0] {\n    font-size: 38px;\n    color: #fff;\n    margin-top: 2px;\n}\n.nav_CompleteIcon[data-v-019a21a0]{\n    /*如果nav_ico的字体大小改变这个值也需要变。 （左边box宽度-back图标宽度)/2 */\n    padding-left: 27px;\n    padding-right: 27px;\n    /*ios识别不出该字体，warn警告。  推测可能隐藏到字体图标的渲染*/\n    /*font-family: Verdana, Geneva, sans-serif;*/\n    font-size: 44px;\n    line-height: 44px;\n    color: #FFFFFF;\n}\n.nav_Complete[data-v-019a21a0] {\n    padding-left: 27px;\n    padding-right: 27px;\n    /*ios识别不出该字体，warn警告。  推测可能隐藏到字体图标的渲染*/\n    /*font-family: Verdana, Geneva, sans-serif;*/\n}\n\n", ""]);

// exports


/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(11)
__webpack_require__(12)

var Component = __webpack_require__(3)(
  /* script */
  __webpack_require__(6),
  /* template */
  __webpack_require__(10),
  /* scopeId */
  "data-v-019a21a0",
  /* cssModules */
  null
)
Component.options.__file = "/Users/ke/mopian/GitHubMoPian/mp/src/include/navbar.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] navbar.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-019a21a0", Component.options)
  } else {
    hotAPI.reload("data-v-019a21a0", Component.options)
  }
})()}

module.exports = Component.exports


/***/ })

/******/ });