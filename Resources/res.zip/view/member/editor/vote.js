// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(194)
	)
	__vue_styles__.push(__webpack_require__(195)
	)

	/* script */
	__vue_exports__ = __webpack_require__(196)

	/* template */
	var __vue_template__ = __webpack_require__(197)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/member/editor/vote.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-4d8322bf"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 89:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 28,
	    "color": "#bbbbbb"
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#bbbbbb",
	    "backgroundColor": "#D9141E"
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#bbbbbb",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderBottomWidth": 0,
	    "borderTopWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#D9141E"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#D9141E"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#D9141E"
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#D9141E"
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#D9141E"
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "backgroundColor": "#D9141E",
	    "borderRadius": 15,
	    "backgroundColor:active": "#bbbbbb",
	    "color:active": "#D9141E",
	    "backgroundColor:disabled": "#D9141E",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#D9141E",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 90:
/***/ (function(module, exports) {

	module.exports = {
	  "nav_back": {
	    "marginTop": 40,
	    "flexDirection": "row",
	    "width": 96,
	    "height": 96,
	    "alignItems": "center",
	    "justifyContent": "center"
	  },
	  "nav_ico": {
	    "fontSize": 38,
	    "color": "#ffffff"
	  },
	  "nav": {
	    "width": 654,
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center",
	    "paddingRight": 30,
	    "marginTop": 40
	  },
	  "nav_Complete": {
	    "fontFamily": "Verdana, Geneva, sans-serif",
	    "fontSize": 34,
	    "lineHeight": 34,
	    "color": "#FFFFFF"
	  }
	}

/***/ }),

/***/ 91:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	exports.default = {
	    props: {
	        title: { default: "navbar" },
	        complete: { default: '' }
	    },
	    methods: {
	        goback: function goback(e) {
	            this.$emit('goback');
	        },
	        goComplete: function goComplete(e) {
	            this.$emit('goComplete');
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 92:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["header"]
	  }, [_c('div', {
	    staticClass: ["nav_back"],
	    on: {
	      "click": function($event) {
	        _vm.goback('/')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["nav_ico"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])]), _c('div', {
	    staticClass: ["nav"]
	  }, [_c('text', {
	    staticClass: ["nav_title"]
	  }, [_vm._v(_vm._s(_vm.title))]), _c('text', {
	    staticClass: ["nav_Complete"],
	    on: {
	      "click": function($event) {
	        _vm.goComplete('/')
	      }
	    }
	  }, [_vm._v(_vm._s(_vm.complete))])])])
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ }),

/***/ 119:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(89)
	)
	__vue_styles__.push(__webpack_require__(90)
	)

	/* script */
	__vue_exports__ = __webpack_require__(91)

	/* template */
	var __vue_template__ = __webpack_require__(92)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/include/navbar.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-29311109"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__


/***/ }),

/***/ 194:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 28,
	    "color": "#bbbbbb"
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#bbbbbb",
	    "backgroundColor": "#D9141E"
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#bbbbbb",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderBottomWidth": 0,
	    "borderTopWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#D9141E"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#D9141E"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#D9141E"
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#D9141E"
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#D9141E"
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "backgroundColor": "#D9141E",
	    "borderRadius": 15,
	    "backgroundColor:active": "#bbbbbb",
	    "color:active": "#D9141E",
	    "backgroundColor:disabled": "#D9141E",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#D9141E",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 195:
/***/ (function(module, exports) {

	module.exports = {
	  "voteBigBox": {
	    "paddingBottom": 20,
	    "borderBottomWidth": 30,
	    "borderStyle": "solid",
	    "borderColor": "#999999"
	  },
	  "flexRow": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "addVote": {
	    "paddingBottom": 15,
	    "paddingTop": 15,
	    "paddingLeft": 45,
	    "paddingRight": 45,
	    "borderRadius": 10,
	    "backgroundColor": "#ffffff"
	  },
	  "circle": {
	    "width": 50,
	    "height": 50,
	    "borderRadius": 25,
	    "backgroundColor": "#ffffff",
	    "borderWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#999999"
	  },
	  "addSize": {
	    "color": "#D9141E",
	    "fontSize": 35
	  },
	  "bottomSize": {
	    "fontSize": 35
	  },
	  "addOptions": {
	    "justifyContent": "center"
	  },
	  "pl10": {
	    "marginLeft": 20
	  },
	  "closeIcon": {
	    "fontSize": 40,
	    "color": "#999999",
	    "fontWeight": "700",
	    "paddingBottom": 10,
	    "paddingTop": 10,
	    "paddingRight": 10,
	    "paddingLeft": 10
	  },
	  "textareaClass": {
	    "width": 485,
	    "fontSize": 35,
	    "lineHeight": 48
	  },
	  "textareaBox": {
	    "height": 120,
	    "justifyContent": "center"
	  },
	  "optionsBox": {
	    "justifyContent": "space-between",
	    "paddingRight": 30
	  },
	  "voteTell": {
	    "flexDirection": "row",
	    "height": 110,
	    "alignItems": "center"
	  },
	  "addBottomBorder": {
	    "borderBottomWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#DCDCDC"
	  },
	  "tellSize": {
	    "fontSize": 37
	  },
	  "voteBox": {
	    "width": 710,
	    "marginLeft": 20,
	    "paddingLeft": 25,
	    "borderRadius": 20,
	    "backgroundColor": "#ffffff"
	  }
	}

/***/ }),

/***/ 196:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _navbar = __webpack_require__(119);

	var _navbar2 = _interopRequireDefault(_navbar);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var event = weex.requireModule('event'); //
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//


	var modal = weex.requireModule('modal');
	var picker = weex.requireModule('picker');
	var isSign = -1;
	var optionIndex = 0;
	exports.default = {
	    data: function data() {
	        return {
	            refreshing: false,
	            voteList: [{}],
	            chooseOptions: '单选(默认)',
	            optionsIndex: 0,
	            chooseDate: '无截止时间',
	            chooseTime: '',
	            optionArray: ['单选(默认)', '多选,无限制', '多选，最多2项'],
	            textAreaTitle: '',
	            titleHeight: 48,
	            titleRows: 1,
	            pageBox: [{
	                textAreaMessage: '',
	                textHeight: '48',
	                rowsNum: '1',
	                editSign: -1
	            }, {
	                textAreaMessage: '',
	                textHeight: 48,
	                rowsNum: 1,
	                editSign: -1
	            }, {
	                textAreaMessage: '',
	                textHeight: 48,
	                rowsNum: 1,
	                editSign: -1
	            }]
	        };
	    },
	    components: {
	        navbar: _navbar2.default
	    },
	    props: {
	        title: { default: "投票设置" },
	        complete: { default: "完成" }
	    },
	    mounted: function mounted() {
	        var domModule = weex.requireModule("dom");
	        domModule.addRule('fontFace', {
	            'fontFamily': 'iconfont',
	            'src': "url('http://cdn.rzico.com/weex/resources/fonts/iconfont.ttf')"
	        });
	    },
	    methods: {
	        //            将选择好的时间 重置
	        noEndTime: function noEndTime() {
	            this.chooseDate = '无截止时间';
	            this.chooseTime = '';
	        },
	        //            选择投票类型
	        pickOptions: function pickOptions() {
	            var _this = this;

	            picker.pick({
	                //                    默认选中
	                index: this.optionsIndex,
	                //                    数据选项
	                items: this.optionArray
	            }, function (event) {
	                if (event.result === 'success') {
	                    //                        更改默认选中的下标
	                    _this.optionsIndex = event.data;
	                    //                        将选择的数据写入chooseOptions
	                    _this.chooseOptions = _this.optionArray[event.data];
	                }
	            });
	        },

	        //            选择日期
	        pickDate: function pickDate() {
	            var _this2 = this;

	            picker.pickDate({
	                value: this.chooseDate
	            }, function (event) {
	                if (event.result === 'success') {
	                    _this2.chooseDate = event.data;
	                    //日期选择完后 马上选择时间。
	                    _this2.pickTime();
	                    if (_this2.chooseTime == '') {
	                        _this2.chooseTime = '请设置时间';
	                    }
	                }
	            });
	        },

	        //            选择时间
	        pickTime: function pickTime() {
	            var _this3 = this;

	            picker.pickTime({
	                value: this.chooseTime
	            }, function (event) {
	                if (event.result === 'success') {
	                    _this3.chooseTime = event.data;
	                }
	            });
	        },

	        //            设置每个选项的提示内容
	        setPlaceholder: function setPlaceholder(index) {
	            return '选项' + parseInt(index + 1);
	        },
	        //            删除制定选项
	        deleteOptions: function deleteOptions(index) {
	            console.log(index);
	            //                modal.toast({message:index,duration:0.3});
	            this.pageBox.splice(index, 1);
	        },
	        //            添加选项
	        addOptions: function addOptions() {
	            this.pageBox.push({
	                textAreaMessage: '',
	                textHeight: 48,
	                rowsNum: 1,
	                editSign: -1
	            });
	        },
	        //            通过获取焦点来获取当前输入的组件下标
	        onfocus: function onfocus(index) {
	            optionIndex = index;
	        },
	        //            选项输入
	        optionsOninput: function optionsOninput(event) {
	            var len = this.getLen(event);
	            //                当字符数超过25时，将多行输入改成2行并且高度设为96
	            modal.toast({ message: len, duration: 0.3 });
	            if (len > 25) {
	                //                    editSign是每个组件的控制符，控制是否切换高度.不用每次输入都执行一次
	                if (this.pageBox[optionIndex].editSign == -1) {
	                    this.pageBox[optionIndex].rowsNum = 2;
	                    this.pageBox[optionIndex].textHeight = 96;
	                    this.pageBox[optionIndex].editSign = 0;
	                }
	            } else {
	                //否则将高度与行数改回来
	                if (this.pageBox[optionIndex].editSign == 0) {
	                    this.pageBox[optionIndex].rowsNum = 1;
	                    this.pageBox[optionIndex].textHeight = 48;
	                    this.pageBox[optionIndex].editSign = -1;
	                }
	            }
	        },

	        //            标题描述输入。
	        titleOninput: function titleOninput(event) {
	            var len = this.getLen(event);
	            //当字符数超过25时，将多行输入改成2行并且高度设为96
	            if (len > 25) {
	                //                    控制是否切换高度.不用每次输入都执行一次
	                if (isSign == -1) {
	                    this.titleRows = 2;
	                    this.titleHeight = 96;
	                    isSign = 0;
	                }
	            } else {
	                //否则将高度与行数改回来
	                if (isSign == 0) {
	                    this.titleRows = 1;
	                    this.titleHeight = 48;
	                    isSign = -1;
	                }
	            }
	        },
	        //            获取已输入的字符总长度
	        getLen: function getLen(event) {
	            var name = event.value;
	            var len = 0;
	            for (var i = 0; i < name.length; i++) {
	                var a = name.charAt(i);
	                if (a.match(/[^\x00-\xff]/ig) != null) {
	                    len += 2;
	                } else {
	                    len += 1;
	                }
	            }
	            return len;
	        },

	        //            添加投票箱
	        addVoteBox: function addVoteBox() {
	            this.voteList.push({});
	        },

	        //            下拉刷新
	        onrefresh: function onrefresh(event) {
	            var _this4 = this;

	            console.log('is refreshing');
	            this.refreshing = true;
	            setTimeout(function () {
	                _this4.refreshing = false;
	            }, 2000);
	        },

	        //            正在下拉
	        onpullingdown: function onpullingdown(event) {
	            console.log('is onpulling down');
	        },

	        //            返回
	        goback: function goback() {
	            event.closeURL();
	        },
	        //            完成
	        goComplete: function goComplete() {
	            event.closeURL(this.textAreaTitle);
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 197:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('scroller', {
	    staticClass: ["wrapper"]
	  }, [_c('navbar', {
	    attrs: {
	      "title": _vm.title,
	      "complete": _vm.complete
	    },
	    on: {
	      "goback": _vm.goback,
	      "goComplete": _vm.goComplete
	    }
	  }), _vm._l((_vm.voteList), function(voteBox) {
	    return _c('div', {
	      staticClass: ["voteBigBox"]
	    }, [_c('div', {
	      staticClass: ["voteBox", "mt20", "border-radius"]
	    }, [_c('div', {
	      staticClass: ["voteTell", "addBottomBorder"]
	    }, [_c('text', {
	      staticClass: ["gray", "tellSize"]
	    }, [_vm._v("投票描述")]), _c('div', {
	      staticClass: ["textareaBox"]
	    }, [_c('textarea', {
	      staticClass: ["textareaClass", "ml10"],
	      style: {
	        height: _vm.titleHeight + 'px'
	      },
	      attrs: {
	        "dataId": "0",
	        "rows": _vm.titleRows,
	        "autofocus": "true",
	        "value": (_vm.textAreaTitle)
	      },
	      on: {
	        "input": [function($event) {
	          _vm.textAreaTitle = $event.target.attr.value
	        }, _vm.titleOninput]
	      }
	    })], 1)]), _vm._l((_vm.pageBox), function(item, index) {
	      return _c('div', {
	        staticClass: ["voteTell", "addBottomBorder", "optionsBox"]
	      }, [_c('text', {
	        staticClass: ["circle", "pl10"]
	      }), _c('div', {
	        staticClass: ["textareaBox"]
	      }, [_c('textarea', {
	        staticClass: ["textareaClass"],
	        style: {
	          height: item.textHeight + 'px'
	        },
	        attrs: {
	          "placeholder": _vm.setPlaceholder(index),
	          "rows": item.rowsNum,
	          "value": (item.textAreaMessage)
	        },
	        on: {
	          "focus": function($event) {
	            _vm.onfocus(index)
	          },
	          "input": [function($event) {
	            item.textAreaMessage = $event.target.attr.value
	          }, _vm.optionsOninput]
	        }
	      })], 1), (index >= 2) ? _c('text', {
	        staticClass: ["closeIcon"],
	        style: {
	          fontFamily: 'iconfont'
	        },
	        on: {
	          "click": function($event) {
	            _vm.deleteOptions(index)
	          }
	        }
	      }, [_vm._v("")]) : _c('text', {
	        staticClass: ["closeIcon"],
	        staticStyle: {
	          width: "40px"
	        }
	      })])
	    }), _c('div', {
	      staticClass: ["voteTell", "addOptions"],
	      on: {
	        "click": function($event) {
	          _vm.addOptions()
	        }
	      }
	    }, [_c('text', {
	      staticClass: ["addSize"]
	    }, [_vm._v("+")]), _c('text', {
	      staticClass: ["addSize", "ml10"]
	    }, [_vm._v("添加选项")])])], 2), _c('div', {
	      staticClass: ["voteBox", "mt20", "border-radius"]
	    }, [_c('div', {
	      staticClass: ["voteTell", "addBottomBorder", "optionsBox"]
	    }, [_c('div', {
	      staticClass: ["flexRow"]
	    }, [_c('text', {
	      staticClass: ["gray", "bottomSize"]
	    }, [_vm._v("截止时间")]), _c('div', {
	      staticClass: ["textareaBox", "ml10", "flexRow"]
	    }, [_c('text', {
	      staticClass: ["bottomSize"],
	      on: {
	        "click": function($event) {
	          _vm.pickDate()
	        }
	      }
	    }, [_vm._v(_vm._s(_vm.chooseDate))]), _c('text', {
	      staticClass: ["bottomSize", "ml10"],
	      on: {
	        "click": function($event) {
	          _vm.pickTime()
	        }
	      }
	    }, [_vm._v(_vm._s(_vm.chooseTime))])])]), (_vm.chooseTime != '') ? _c('text', {
	      staticClass: ["closeIcon"],
	      style: {
	        fontFamily: 'iconfont'
	      },
	      on: {
	        "click": function($event) {
	          _vm.noEndTime()
	        }
	      }
	    }, [_vm._v("")]) : _vm._e()]), _c('div', {
	      staticClass: ["voteTell"]
	    }, [_c('text', {
	      staticClass: ["gray", "bottomSize"]
	    }, [_vm._v("投票类型")]), _c('div', {
	      staticClass: ["textareaBox", "ml10"],
	      on: {
	        "click": function($event) {
	          _vm.pickOptions()
	        }
	      }
	    }, [_c('text', {
	      staticClass: ["bottomSize"]
	    }, [_vm._v(_vm._s(_vm.chooseOptions))])])])])])
	  }), _c('div', {
	    staticClass: ["voteTell", "addOptions"],
	    on: {
	      "click": function($event) {
	        _vm.addVoteBox()
	      }
	    }
	  }, [_c('div', {
	    staticClass: ["flexRow", "addVote"]
	  }, [_c('text', {
	    staticClass: ["addSize"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")]), _c('text', {
	    staticClass: ["addSize", "ml10"]
	  }, [_vm._v("添加投票")])])])], 2)
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ })

/******/ });