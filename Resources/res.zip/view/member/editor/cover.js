// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(172)
	)

	/* script */
	__vue_exports__ = __webpack_require__(173)

	/* template */
	var __vue_template__ = __webpack_require__(174)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/member/editor/cover.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-61920f9c"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 89:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 28,
	    "color": "#bbbbbb"
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#bbbbbb",
	    "backgroundColor": "#D9141E"
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#bbbbbb",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderBottomWidth": 0,
	    "borderTopWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#D9141E"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#D9141E"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#D9141E"
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#D9141E"
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#D9141E"
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "backgroundColor": "#D9141E",
	    "borderRadius": 15,
	    "backgroundColor:active": "#bbbbbb",
	    "color:active": "#D9141E",
	    "backgroundColor:disabled": "#D9141E",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#D9141E",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 90:
/***/ (function(module, exports) {

	module.exports = {
	  "nav_back": {
	    "marginTop": 40,
	    "flexDirection": "row",
	    "width": 96,
	    "height": 96,
	    "alignItems": "center",
	    "justifyContent": "center"
	  },
	  "nav_ico": {
	    "fontSize": 38,
	    "color": "#ffffff"
	  },
	  "nav": {
	    "width": 654,
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center",
	    "paddingRight": 30,
	    "marginTop": 40
	  },
	  "nav_Complete": {
	    "fontFamily": "Verdana, Geneva, sans-serif",
	    "fontSize": 34,
	    "lineHeight": 34,
	    "color": "#FFFFFF"
	  }
	}

/***/ }),

/***/ 91:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	exports.default = {
	    props: {
	        title: { default: "navbar" },
	        complete: { default: '' }
	    },
	    methods: {
	        goback: function goback(e) {
	            this.$emit('goback');
	        },
	        goComplete: function goComplete(e) {
	            this.$emit('goComplete');
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 92:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["header"]
	  }, [_c('div', {
	    staticClass: ["nav_back"],
	    on: {
	      "click": function($event) {
	        _vm.goback('/')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["nav_ico"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])]), _c('div', {
	    staticClass: ["nav"]
	  }, [_c('text', {
	    staticClass: ["nav_title"]
	  }, [_vm._v(_vm._s(_vm.title))]), _c('text', {
	    staticClass: ["nav_Complete"],
	    on: {
	      "click": function($event) {
	        _vm.goComplete('/')
	      }
	    }
	  }, [_vm._v(_vm._s(_vm.complete))])])])
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ }),

/***/ 119:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(89)
	)
	__vue_styles__.push(__webpack_require__(90)
	)

	/* script */
	__vue_exports__ = __webpack_require__(91)

	/* template */
	var __vue_template__ = __webpack_require__(92)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/include/navbar.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-29311109"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__


/***/ }),

/***/ 172:
/***/ (function(module, exports) {

	module.exports = {
	  "bottomBorderSub": {
	    "borderBottomWidth": 1
	  },
	  "topBorderSub": {
	    "borderTopWidth": 1
	  },
	  "rightBorderSub": {
	    "borderRightWidth": 1
	  },
	  "leftBorderSub": {
	    "borderLeftWidth": 1
	  },
	  "colorBlue": {
	    "backgroundColor": "#ffffff"
	  },
	  "colorBlack": {
	    "color": "#000000"
	  },
	  "colorPink": {
	    "backgroundColor": "#FFC0CB",
	    "marginRight": 1
	  },
	  "colorCoral": {
	    "backgroundColor": "#FF7F50"
	  },
	  "colorText": {
	    "color": "#ffffff",
	    "fontWeight": "700",
	    "fontSize": 25
	  },
	  "borderColorSize": {
	    "fontSize": 25
	  },
	  "colorTextBox": {
	    "flex": 1,
	    "alignItems": "center",
	    "backgroundColor": "#ffffff",
	    "justifyContent": "center"
	  },
	  "colorChoose": {
	    "width": 750,
	    "height": 80,
	    "flexDirection": "row",
	    "marginTop": 40,
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "paddingRight": 20
	  },
	  "shareTitle": {
	    "lines": 1,
	    "textOverflow": "ellipsis",
	    "color": "#333333",
	    "fontSize": 36,
	    "lineHeight": 50
	  },
	  "shareText": {
	    "color": "#cccccc",
	    "fontSize": 28,
	    "lineHeight": 38,
	    "lines": 3,
	    "textOverflow": "ellipsis"
	  },
	  "shareTextBox": {
	    "width": 460,
	    "paddingLeft": 10
	  },
	  "shareImageBox": {
	    "height": 160,
	    "width": 160
	  },
	  "shareContent": {
	    "width": 660,
	    "height": 200,
	    "marginLeft": 45,
	    "flexDirection": "row",
	    "backgroundColor": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "paddingLeft": 20,
	    "paddingRight": 20
	  },
	  "shareTitleText": {
	    "fontSize": 32,
	    "color": "#999999"
	  },
	  "shareTitleHead": {
	    "paddingBottom": 30,
	    "paddingTop": 40,
	    "alignItems": "center",
	    "width": 750
	  },
	  "wrapperBox": {
	    "backgroundColor": "#EFF0F5"
	  },
	  "chooseNumber": {
	    "width": 750,
	    "flexDirection": "row",
	    "justifyContent": "center",
	    "alignItems": "center",
	    "marginTop": 20
	  },
	  "active": {
	    "backgroundColor": "#88bde6",
	    "color": "#ffffff"
	  },
	  "imgNumber": {
	    "borderWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "#DCDCDC",
	    "color": "#F0AD3C",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "fontSize": 38,
	    "flex": 1,
	    "textAlign": "center"
	  },
	  "coverImageBox": {
	    "width": 750,
	    "height": 310
	  },
	  "fiveImage": {
	    "flex": 1,
	    "flexDirection": "column"
	  },
	  "fourImage": {
	    "flex": 1,
	    "flexDirection": "column"
	  },
	  "twoImage": {
	    "flexDirection": "row",
	    "flex": 1
	  },
	  "threeImage": {
	    "flex": 1,
	    "flexDirection": "column"
	  },
	  "oneImage": {
	    "flex": 1
	  },
	  "coverImage": {
	    "flex": 1,
	    "borderStyle": "solid",
	    "borderWidth": 1
	  }
	}

/***/ }),

/***/ 173:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _navbar = __webpack_require__(119);

	var _navbar2 = _interopRequireDefault(_navbar);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	var modal = weex.requireModule('modal'); //
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var album = weex.requireModule('album');
	var event = weex.requireModule('event');
	exports.default = {
	    data: function data() {
	        return {
	            coverBorder: 'white',
	            imageNumber: 1,
	            coverImage: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg',
	            coverImageTwo: 'https://gd2.alicdn.com/bao/uploaded/i2/T14H1LFwBcXXXXXXXX_!!0-item_pic.jpg',
	            coverImageThree: 'https://gd1.alicdn.com/bao/uploaded/i1/TB1PXJCJFXXXXciXFXXXXXXXXXX_!!0-item_pic.jpg',
	            shareText: '   《惊喜魔篇》历时三十天，总行程两万里《横穿玛丽亚》历时三十天，总行程两万里《横穿玛丽亚》历时三十天，总行程两万里《横穿玛丽亚》历时三十天，总行程两万里',
	            shareTitle: '  《惊喜魔篇》',
	            allCoverImage: [{ imgUrl: 'https://gd3.alicdn.com/bao/uploaded/i3/TB1x6hYLXXXXXazXVXXXXXXXXXX_!!0-item_pic.jpg' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, {
	                imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }, { imgUrl: '' }]
	        };
	    },
	    components: {
	        navbar: _navbar2.default
	    },
	    props: {
	        title: { default: "编辑封面" },
	        complete: { default: "完成" }
	    },
	    mounted: function mounted() {
	        var domModule = weex.requireModule("dom");
	        domModule.addRule('fontFace', {
	            'fontFamily': 'iconfont',
	            'src': "url('http://cdn.rzico.com/weex/resources/fonts/iconfont.ttf')"
	        });
	    },
	    methods: {
	        changeBorderColor: function changeBorderColor(value) {
	            this.coverBorder = value;
	        },
	        changeImageNumber: function changeImageNumber(num) {
	            switch (num) {
	                case 1:
	                    this.imageNumber = 1;
	                    break;
	                case 2:
	                    this.imageNumber = 2;
	                    break;
	                case 3:
	                    this.imageNumber = 3;
	                    break;
	                case 4:
	                    this.imageNumber = 4;
	                    break;
	                case 5:
	                    this.imageNumber = 5;
	                    break;
	                case 6:
	                    this.imageNumber = 6;
	                    break;

	            }
	        },
	        //            点击图片时
	        clickImage: function clickImage(num) {
	            var _this = this;
	            //                如果没有图片就调用单选接口
	            if (_this.allCoverImage[num].imgUrl == '') {
	                album.openAlbumSingle(false, function (data) {
	                    if (data.type == 'success') {
	                        modal.toast({ message: data });
	                        //                        _this.allCoverImage[num].imgUrl =  data.data;
	                    } else {
	                        modal.toast({ message: data.content, duration: 3 });
	                    }
	                });
	            } else {
	                var _this = this;
	                //                    如果已经有图片了就调用裁剪图片
	                album.openCrop(_this.allCoverImage[num].imgUrl, function (data) {
	                    _this.allCoverImage[num].imgUrl = data.data;
	                });
	            }
	        },
	        goback: function goback() {
	            event.closeURL();
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 174:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["wrapperBox"]
	  }, [_c('navbar', {
	    attrs: {
	      "title": _vm.title,
	      "complete": _vm.complete
	    },
	    on: {
	      "goback": _vm.goback,
	      "goComplete": _vm.goComplete
	    }
	  }), _c('div', {
	    staticClass: ["coverImageBox"]
	  }, [(_vm.imageNumber == 1) ? _c('div', {
	    staticClass: ["oneImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[0].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(0)
	      }
	    }
	  })]) : _vm._e(), (_vm.imageNumber == 2) ? _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[1].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(1)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[2].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(2)
	      }
	    }
	  })]) : _vm._e(), (_vm.imageNumber == 3) ? _c('div', {
	    staticClass: ["threeImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[3].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(3)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "leftBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[4].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(4)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[5].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(5)
	      }
	    }
	  })])]) : _vm._e(), (_vm.imageNumber == 4) ? _c('div', {
	    staticClass: ["fourImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[6].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(6)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[7].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(7)
	      }
	    }
	  })]), _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[8].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(8)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[9].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(9)
	      }
	    }
	  })])]) : _vm._e(), (_vm.imageNumber == 5) ? _c('div', {
	    staticClass: ["fiveImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[10].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(10)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[11].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(11)
	      }
	    }
	  })]), _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[12].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(12)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[13].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(13)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[14].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(14)
	      }
	    }
	  })])]) : _vm._e(), (_vm.imageNumber == 6) ? _c('div', {
	    staticClass: ["fiveImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[15].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(15)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub", "rightBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[16].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(16)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[17].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(17)
	      }
	    }
	  })]), _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[18].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(18)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[19].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(19)
	      }
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[20].imgUrl
	    },
	    on: {
	      "click": function($event) {
	        _vm.clickImage(20)
	      }
	    }
	  })])]) : _vm._e()]), _c('div', {
	    staticClass: ["chooseNumber"]
	  }, [_c('text', {
	    staticClass: ["imgNumber"],
	    class: [_vm.imageNumber == 3 ? 'active' : ''],
	    style: {
	      fontFamily: 'iconfont'
	    },
	    on: {
	      "click": function($event) {
	        _vm.changeImageNumber(3)
	      }
	    }
	  }, [_vm._v("")]), _c('text', {
	    staticClass: ["imgNumber"],
	    class: [_vm.imageNumber == 4 ? 'active' : ''],
	    style: {
	      fontFamily: 'iconfont'
	    },
	    on: {
	      "click": function($event) {
	        _vm.changeImageNumber(4)
	      }
	    }
	  }, [_vm._v("")]), _c('text', {
	    staticClass: ["imgNumber"],
	    class: [_vm.imageNumber == 2 ? 'active' : ''],
	    style: {
	      fontFamily: 'iconfont'
	    },
	    on: {
	      "click": function($event) {
	        _vm.changeImageNumber(2)
	      }
	    }
	  }, [_vm._v("")]), _c('text', {
	    staticClass: ["imgNumber"],
	    class: [_vm.imageNumber == 1 ? 'active' : ''],
	    style: {
	      fontFamily: 'iconfont'
	    },
	    on: {
	      "click": function($event) {
	        _vm.changeImageNumber(1)
	      }
	    }
	  }, [_vm._v("")]), _c('text', {
	    staticClass: ["imgNumber"],
	    class: [_vm.imageNumber == 5 ? 'active' : ''],
	    style: {
	      fontFamily: 'iconfont'
	    },
	    on: {
	      "click": function($event) {
	        _vm.changeImageNumber(5)
	      }
	    }
	  }, [_vm._v("")]), _c('text', {
	    staticClass: ["imgNumber"],
	    class: [_vm.imageNumber == 6 ? 'active' : ''],
	    style: {
	      fontFamily: 'iconfont'
	    },
	    on: {
	      "click": function($event) {
	        _vm.changeImageNumber(6)
	      }
	    }
	  }, [_vm._v("")])]), _c('div', {
	    staticClass: ["colorChoose"]
	  }, [_vm._m(0), _c('div', {
	    staticClass: ["colorTextBox", "colorCoral"],
	    on: {
	      "click": function($event) {
	        _vm.changeBorderColor('coral')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["colorText"]
	  }, [_vm._v("褐色")])]), _c('div', {
	    staticClass: ["colorTextBox", "colorBlue"],
	    on: {
	      "click": function($event) {
	        _vm.changeBorderColor('white')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["colorText", "colorBlack"]
	  }, [_vm._v("白色")])]), _c('div', {
	    staticClass: ["colorTextBox", "colorPink"],
	    on: {
	      "click": function($event) {
	        _vm.changeBorderColor('pink')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["colorText"]
	  }, [_vm._v("粉色")])])]), _c('list', [_c('cell', {
	    appendAsTree: true,
	    attrs: {
	      "append": "tree"
	    }
	  }, [_vm._m(1), _c('div', {
	    staticClass: ["shareContent"]
	  }, [_c('div', {
	    staticClass: ["shareImageBox"]
	  }, [(_vm.imageNumber == 1) ? _c('div', {
	    staticClass: ["oneImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[0].imgUrl
	    }
	  })]) : _vm._e(), (_vm.imageNumber == 2) ? _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[1].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[2].imgUrl
	    }
	  })]) : _vm._e(), (_vm.imageNumber == 3) ? _c('div', {
	    staticClass: ["threeImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[3].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "leftBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[4].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[5].imgUrl
	    }
	  })])]) : _vm._e(), (_vm.imageNumber == 4) ? _c('div', {
	    staticClass: ["fourImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[6].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[7].imgUrl
	    }
	  })]), _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[8].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[9].imgUrl
	    }
	  })])]) : _vm._e(), (_vm.imageNumber == 5) ? _c('div', {
	    staticClass: ["fiveImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[10].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[11].imgUrl
	    }
	  })]), _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[12].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[13].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[14].imgUrl
	    }
	  })])]) : _vm._e(), (_vm.imageNumber == 6) ? _c('div', {
	    staticClass: ["fiveImage"]
	  }, [_c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[15].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub", "rightBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[16].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "bottomBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[17].imgUrl
	    }
	  })]), _c('div', {
	    staticClass: ["twoImage"]
	  }, [_c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[18].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "rightBorderSub", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[19].imgUrl
	    }
	  }), _c('image', {
	    staticClass: ["coverImage", "leftBorderSub", "topBorderSub"],
	    style: {
	      borderColor: _vm.coverBorder
	    },
	    attrs: {
	      "src": _vm.allCoverImage[20].imgUrl
	    }
	  })])]) : _vm._e()]), _c('div', {
	    staticClass: ["shareTextBox"]
	  }, [_c('text', {
	    staticClass: ["shareTitle"]
	  }, [_vm._v(_vm._s(_vm.shareTitle))]), _c('text', {
	    staticClass: ["shareText"]
	  }, [_vm._v(_vm._s(_vm.shareText))])])])])])], 1)
	},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["colorTextBox"]
	  }, [_c('text', {
	    staticClass: ["borderColorSize"]
	  }, [_vm._v("边框颜色:")])])
	},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["shareTitleHead"]
	  }, [_c('text', {
	    staticClass: ["shareTitleText"]
	  }, [_vm._v("分享到社交平台效果")])])
	}]}
	module.exports.render._withStripped = true

/***/ })

/******/ });