// { "framework": "Vue" }
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(122)
	)

	/* script */
	__vue_exports__ = __webpack_require__(123)

	/* template */
	var __vue_template__ = __webpack_require__(124)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/view/friend/list.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-e8153d92"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__
	module.exports.el = 'true'
	new Vue(module.exports)


/***/ }),

/***/ 89:
/***/ (function(module, exports) {

	module.exports = {
	  "wrapper": {
	    "position": "absolute",
	    "top": 0,
	    "left": 0,
	    "right": 0,
	    "bottom": 0,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "nav_title": {
	    "fontSize": 38,
	    "color": "#ffffff",
	    "lineHeight": 38
	  },
	  "title": {
	    "fontSize": 32,
	    "color": "#000000"
	  },
	  "sub_title": {
	    "fontSize": 28,
	    "color": "#bbbbbb"
	  },
	  "mt10": {
	    "marginTop": 10
	  },
	  "mt20": {
	    "marginTop": 20
	  },
	  "mt30": {
	    "marginTop": 30
	  },
	  "ml10": {
	    "marginLeft": 10
	  },
	  "ml20": {
	    "marginLeft": 20
	  },
	  "ml30": {
	    "marginLeft": 30
	  },
	  "header": {
	    "height": 136,
	    "flexDirection": "row",
	    "position": "sticky",
	    "borderBottomWidth": 1,
	    "borderBottomStyle": "solid",
	    "borderBottomColor": "#bbbbbb",
	    "backgroundColor": "#D9141E"
	  },
	  "footer": {
	    "position": "fixed",
	    "bottom": 0,
	    "left": 0,
	    "right": 0,
	    "height": 100
	  },
	  "fill": {
	    "height": 500,
	    "width": 750,
	    "backgroundColor": "#eeeeee"
	  },
	  "cell-header": {
	    "height": 70,
	    "flexDirection": "row",
	    "backgroundColor": "#dddddd",
	    "paddingLeft": 20
	  },
	  "cell-row": {
	    "minHeight": 100,
	    "flexDirection": "column",
	    "backgroundColor": "#ffffff",
	    "paddingLeft": 20,
	    "marginTop": 20
	  },
	  "cell-line": {
	    "borderTopWidth": 1,
	    "borderTopColor": "#bbbbbb",
	    "borderTopStyle": "solid",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-panel": {
	    "height": 98,
	    "minHeight": 98,
	    "flexDirection": "row",
	    "alignItems": "center",
	    "borderBottomWidth": 1,
	    "borderBottomColor": "#bbbbbb",
	    "borderBottomStyle": "solid"
	  },
	  "cell-clear": {
	    "marginTop": 0,
	    "marginBottom": 0,
	    "borderBottomWidth": 0,
	    "borderTopWidth": 0
	  },
	  "space-between": {
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-start": {
	    "justifyContent": "flex-start",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-end": {
	    "justifyContent": "flex-end",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-center": {
	    "justifyContent": "center",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "space-around": {
	    "justifyContent": "space-around",
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-row": {
	    "flexDirection": "row",
	    "alignItems": "center"
	  },
	  "flex-column": {
	    "flexDirection": "column",
	    "alignItems": "center"
	  },
	  "flex1": {
	    "flex": 1
	  },
	  "flex2": {
	    "flex": 2
	  },
	  "flex3": {
	    "flex": 3
	  },
	  "flex4": {
	    "flex": 4
	  },
	  "flex5": {
	    "flex": 6
	  },
	  "bkg-white": {
	    "backgroundColor": "#FFFFFF"
	  },
	  "bkg-primary": {
	    "backgroundColor": "#D9141E"
	  },
	  "bkg-gray": {
	    "backgroundColor": "#eeeeee"
	  },
	  "white": {
	    "color": "#FFFFFF"
	  },
	  "primary": {
	    "color": "#D9141E"
	  },
	  "gray": {
	    "color": "#bbbbbb"
	  },
	  "ico": {
	    "fontSize": 48,
	    "color": "#D9141E"
	  },
	  "ico_big": {
	    "fontSize": 72,
	    "color": "#D9141E"
	  },
	  "ico_small": {
	    "fontSize": 32,
	    "color": "#D9141E"
	  },
	  "arrow": {
	    "fontSize": 32,
	    "color": "#cccccc",
	    "width": 40
	  },
	  "button": {
	    "fontSize": 36,
	    "textAlign": "center",
	    "color": "#ffffff",
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "backgroundColor": "#D9141E",
	    "borderRadius": 15,
	    "backgroundColor:active": "#bbbbbb",
	    "color:active": "#D9141E",
	    "backgroundColor:disabled": "#D9141E",
	    "color:disabled": "#999999"
	  },
	  "refresh": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "loading": {
	    "flexDirection": "column",
	    "alignItems": "center",
	    "paddingTop": 10
	  },
	  "gif": {
	    "width": 50,
	    "height": 50
	  },
	  "indicator": {
	    "fontSize": 36,
	    "color": "#D9141E",
	    "width": 750,
	    "textAlign": "center",
	    "marginTop": 20,
	    "marginBottom": 20
	  },
	  "lines-ellipsis": {
	    "lines": 1,
	    "textOverflow": "ellipsis"
	  }
	}

/***/ }),

/***/ 90:
/***/ (function(module, exports) {

	module.exports = {
	  "nav_back": {
	    "marginTop": 40,
	    "flexDirection": "row",
	    "width": 96,
	    "height": 96,
	    "alignItems": "center",
	    "justifyContent": "center"
	  },
	  "nav_ico": {
	    "fontSize": 38,
	    "color": "#ffffff"
	  },
	  "nav": {
	    "width": 654,
	    "justifyContent": "space-between",
	    "flexDirection": "row",
	    "alignItems": "center",
	    "paddingRight": 30,
	    "marginTop": 40
	  },
	  "nav_Complete": {
	    "fontFamily": "Verdana, Geneva, sans-serif",
	    "fontSize": 34,
	    "lineHeight": 34,
	    "color": "#FFFFFF"
	  }
	}

/***/ }),

/***/ 91:
/***/ (function(module, exports) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	exports.default = {
	    props: {
	        title: { default: "navbar" },
	        complete: { default: '' }
	    },
	    methods: {
	        goback: function goback(e) {
	            this.$emit('goback');
	        },
	        goComplete: function goComplete(e) {
	            this.$emit('goComplete');
	        }
	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 92:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticClass: ["header"]
	  }, [_c('div', {
	    staticClass: ["nav_back"],
	    on: {
	      "click": function($event) {
	        _vm.goback('/')
	      }
	    }
	  }, [_c('text', {
	    staticClass: ["nav_ico"],
	    style: {
	      fontFamily: 'iconfont'
	    }
	  }, [_vm._v("")])]), _c('div', {
	    staticClass: ["nav"]
	  }, [_c('text', {
	    staticClass: ["nav_title"]
	  }, [_vm._v(_vm._s(_vm.title))]), _c('text', {
	    staticClass: ["nav_Complete"],
	    on: {
	      "click": function($event) {
	        _vm.goComplete('/')
	      }
	    }
	  }, [_vm._v(_vm._s(_vm.complete))])])])
	},staticRenderFns: []}
	module.exports.render._withStripped = true

/***/ }),

/***/ 119:
/***/ (function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = []

	/* styles */
	__vue_styles__.push(__webpack_require__(89)
	)
	__vue_styles__.push(__webpack_require__(90)
	)

	/* script */
	__vue_exports__ = __webpack_require__(91)

	/* template */
	var __vue_template__ = __webpack_require__(92)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/zhangsr/Documents/GitHub/weex/mp/src/include/navbar.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-29311109"
	__vue_options__.style = __vue_options__.style || {}
	__vue_styles__.forEach(function (module) {
	  for (var name in module) {
	    __vue_options__.style[name] = module[name]
	  }
	})
	if (typeof __register_static_styles__ === "function") {
	  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
	}

	module.exports = __vue_exports__


/***/ }),

/***/ 122:
/***/ (function(module, exports) {

	module.exports = {
	  "letterList": {
	    "color": "#494949",
	    "fontSize": 29
	  },
	  "friendTotalBox": {
	    "width": 750,
	    "alignItems": "center",
	    "paddingTop": 40,
	    "paddingBottom": 40,
	    "backgroundColor": "#F2F3F8"
	  },
	  "friendTotalText": {
	    "fontSize": 34,
	    "color": "#888888"
	  },
	  "letterOnPress": {
	    "backgroundColor": "#B3B2B3"
	  },
	  "letterNavBox": {
	    "position": "absolute",
	    "right": 0,
	    "width": 60,
	    "top": 110,
	    "bottom": 0,
	    "paddingBottom": 15,
	    "paddingTop": 20,
	    "alignItems": "center"
	  },
	  "letterNav": {
	    "flex": 1,
	    "width": 60,
	    "alignItems": "center"
	  },
	  "friendsName": {
	    "height": 90,
	    "marginTop": 15,
	    "justifyContent": "space-between"
	  },
	  "letterBox": {
	    "width": 750,
	    "paddingLeft": 30,
	    "paddingTop": 5,
	    "paddingBottom": 5,
	    "backgroundColor": "#e8e8e8"
	  },
	  "addBorder": {
	    "borderBottomWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "rgba(153,153,153,0.5)"
	  },
	  "nameLetter": {
	    "color": "#888888",
	    "fontSize": 24
	  },
	  "realName": {
	    "color": "#888888",
	    "fontSize": 30,
	    "marginLeft": 20
	  },
	  "friendsImage": {
	    "marginTop": 20,
	    "height": 80,
	    "width": 80
	  },
	  "addFriendsBorder": {
	    "borderBottomWidth": 1,
	    "borderStyle": "solid",
	    "borderColor": "rgba(153,153,153,0.2)"
	  },
	  "friendsLine": {
	    "paddingLeft": 30,
	    "height": 120,
	    "width": 660,
	    "backgroundColor": "#ffffff",
	    "flexDirection": "row"
	  },
	  "listBody": {
	    "backgroundColor": "#ffffff"
	  },
	  "topLine": {
	    "flexDirection": "row",
	    "width": 660,
	    "paddingTop": 20,
	    "paddingBottom": 20,
	    "paddingLeft": 30,
	    "alignItems": "center",
	    "backgroundColor": "#ffffff"
	  },
	  "lineImage": {
	    "width": 80,
	    "height": 80
	  },
	  "lineTitle": {
	    "fontSize": 34,
	    "marginLeft": 20
	  }
	}

/***/ }),

/***/ 123:
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _navbar = __webpack_require__(119);

	var _navbar2 = _interopRequireDefault(_navbar);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	var modal = weex.requireModule('modal');
	var navigator = weex.requireModule('navigator');
	var native = weex.requireModule('app');

	var dom = weex.requireModule('dom');
	var stream = weex.requireModule('stream');
	var pressPoint = -1; //手指按压
	var movePoint; //手机按压后移动
	var pointPoor; //手机按压时与移动后的字母数量
	var moveLetter; //移动后的字母
	var beforePointPoor = -1; //前一次手机按压时与移动后的字母数量
	exports.default = {
	    data: function data() {
	        return {
	            //                    text:'Jum333132p',
	            isPress: false,
	            friendTotal: 43,
	            topLineList: [{
	                lineImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                lineTitle: '新的朋友'
	            }, {
	                lineImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                lineTitle: '我的粉丝'
	            }, {
	                lineImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                lineTitle: '功能1'
	            }, {
	                lineImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                lineTitle: '功能2'
	            }],
	            friendsList: [{
	                letter: 'A',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'B',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '大咖秀',
	                    realName: '王龙'
	                }]
	            }, {
	                letter: 'C',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'D',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'E',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'F',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'H',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'J',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'K',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'L',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'M',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'N',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'O',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'P',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'Q',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'R',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'S',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'T',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'W',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'X',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'Y',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: 'Z',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '番茄',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '炒蛋',
	                    realName: '杨彩铃'
	                }]
	            }, {
	                letter: '#',
	                name: [{
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '19',
	                    realName: '炒茄子'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '2333',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '455',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '639',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '455',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '639',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '455',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '639',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '455',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '639',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '455',
	                    realName: '杨彩铃'
	                }, {
	                    friendImage: 'https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg',
	                    friendName: '639',
	                    realName: '杨彩铃'
	                }]
	            }],
	            allLetter: ['||', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '#']
	        };
	    },
	    props: {
	        title: { default: "新的朋友" },
	        complete: { default: "添加朋友" }
	    },
	    created: function created() {
	        modal.toast({ message: '111', duration: 1 });
	        this.getFriendList(function (res) {
	            modal.toast({ message: res.data, duration: 1 });
	        });
	    },

	    methods: {
	        getFriendList: function getFriendList(callback) {
	            return stream.fetch({
	                method: 'GET',
	                type: 'json',
	                url: '/weex/member/friends/list.jhtml'
	            }, callback);
	        },

	        goComplete: function goComplete() {},
	        goback: function goback() {
	            event.closeURL();
	        },
	        jump: function jump(vueName) {
	            modal.toast({ message: '点击了信息栏' });
	        },
	        onlongpress: function onlongpress(count) {
	            modal.toast({ message: this.allLetter[count], duration: 0.3 });
	            this.isPress = true;
	        },
	        ontouchstart: function ontouchstart(count) {
	            if (count == 0) {
	                //判断是否点击回到顶部
	                var el = this.$refs.linkref[count]; //跳转到相应的cell
	                dom.scrollToElement(el, {
	                    //                        animated:false
	                });
	            } else {
	                for (var i = 0; i < this.friendsList.length; i++) {
	                    //循环判断是否有相应首字母的朋友
	                    if (this.friendsList[i].letter == this.allLetter[count]) {
	                        var _el = this.$refs.listref[i]; //跳转到相应的cell
	                        dom.scrollToElement(_el, {
	                            //                                animated:false
	                        });
	                    }
	                }
	            }
	            modal.toast({ message: this.allLetter[count], duration: 0.3 });
	            this.isPress = true;
	        },
	        ontouchend: function ontouchend() {
	            this.isPress = false;
	            pressPoint = -1; //重置判断是否刚开始滑动的标志符（可以不用，点击并长按时已经帮忙弥补了该数据的漏洞）
	            beforePointPoor == -1; //（可以不用，点击并长按时已经帮忙弥补了该数据的漏洞）
	        },
	        //        ==============================
	        ontouchmove: function ontouchmove(count, event) {
	            //按住字母导航栏并拖动时触发
	            if (pressPoint == -1) {
	                //记录每次第一次滑动按压的点
	                pressPoint = event.changedTouches[0].pageY;
	            } else {
	                movePoint = Math.abs(pressPoint - event.changedTouches[0].pageY); //求移动的距离(绝对值)
	                if (movePoint > 35) {
	                    pointPoor = Math.floor(movePoint / 35); //通过偏移量获取上移的字母数量
	                    if (!(beforePointPoor == -1 || beforePointPoor == pointPoor)) {
	                        if (pressPoint - event.changedTouches[0].pageY >= 0) {
	                            moveLetter = count - pointPoor; //获取目前手指停留的字母下标
	                        } else {
	                            moveLetter = count + pointPoor; //获取目前手指停留的字母
	                        }
	                        for (var i = 0; i < this.friendsList.length; i++) {
	                            //循环判断是否有相应首字母的朋友
	                            if (this.friendsList[i].letter == this.allLetter[moveLetter]) {
	                                var el = this.$refs.listref[i]; //跳转到相应的cell
	                                dom.scrollToElement(el, {
	                                    //                                        animated:false
	                                });
	                            } else if (moveLetter == 0) {
	                                //判断是否滑到 顶部按钮
	                                var _el2 = this.$refs.linkref[moveLetter]; //跳转到相应的cell
	                                dom.scrollToElement(_el2, {
	                                    //                                        animated:false
	                                });
	                            }
	                        }
	                        modal.toast({ message: this.allLetter[moveLetter], duration: 0.001 }); //弹出提示框toast
	                    }
	                    beforePointPoor = pointPoor; //把这次的滑动的字母数量保存起来
	                }
	            }
	        }

	    }
	};
	module.exports = exports['default'];

/***/ }),

/***/ 124:
/***/ (function(module, exports) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', [_c('navbar', {
	    attrs: {
	      "title": _vm.title,
	      "complete": _vm.complete
	    },
	    on: {
	      "goback": _vm.goback,
	      "goComplete": _vm.goComplete
	    }
	  }), _vm._m(0), _c('list', {
	    staticClass: ["listBody"]
	  }, [_vm._l((_vm.topLineList), function(item) {
	    return _c('cell', {
	      ref: "linkref",
	      refInFor: true,
	      appendAsTree: true,
	      attrs: {
	        "append": "tree"
	      }
	    }, [_c('div', {
	      staticClass: ["addBorder"]
	    }, [_c('div', {
	      staticClass: ["topLine"],
	      on: {
	        "click": function($event) {
	          _vm.jump('/member')
	        }
	      }
	    }, [_c('image', {
	      staticClass: ["lineImage"],
	      attrs: {
	        "src": item.lineImage
	      }
	    }), _c('text', {
	      staticClass: ["lineTitle"]
	    }, [_vm._v(_vm._s(item.lineTitle))])])])])
	  }), _vm._l((_vm.friendsList), function(friend) {
	    return _c('cell', {
	      ref: "listref",
	      refInFor: true,
	      appendAsTree: true,
	      attrs: {
	        "append": "tree"
	      }
	    }, [_c('div', {
	      staticClass: ["letterBox"]
	    }, [_c('text', {
	      staticClass: ["nameLetter"]
	    }, [_vm._v(_vm._s(friend.letter))])]), _vm._l((friend.name), function(item) {
	      return _c('div', [_c('div', {
	        staticClass: ["addFriendsBorder"]
	      }, [_c('div', {
	        staticClass: ["friendsLine"],
	        on: {
	          "click": function($event) {
	            _vm.jump('/member')
	          }
	        }
	      }, [_c('image', {
	        staticClass: ["friendsImage"],
	        attrs: {
	          "src": item.friendImage
	        }
	      }), _c('div', {
	        staticClass: ["friendsName"]
	      }, [_c('text', {
	        staticClass: ["lineTitle"]
	      }, [_vm._v(_vm._s(item.friendName))]), _c('text', {
	        staticClass: ["realName"]
	      }, [_vm._v("真实姓名:" + _vm._s(item.realName))])])])])])
	    })], 2)
	  }), _c('cell', {
	    appendAsTree: true,
	    attrs: {
	      "append": "tree"
	    }
	  }, [_c('div', {
	    staticClass: ["friendTotalBox"]
	  }, [_c('text', {
	    staticClass: ["friendTotalText"]
	  }, [_vm._v(_vm._s(_vm.friendTotal) + "个朋友")])])])], 2), _c('div', {
	    staticClass: ["letterNavBox"],
	    class: [_vm.isPress ? 'letterOnPress' : '']
	  }, _vm._l((_vm.allLetter), function(item, index) {
	    return _c('div', {
	      staticClass: ["letterNav"],
	      on: {
	        "longpress": function($event) {
	          _vm.onlongpress(index)
	        },
	        "touchstart": function($event) {
	          _vm.ontouchstart(index)
	        },
	        "touchend": function($event) {
	          _vm.ontouchend()
	        },
	        "touchmove": function($event) {
	          _vm.ontouchmove(index, $event)
	        }
	      }
	    }, [_c('text', {
	      staticClass: ["letterList"]
	    }, [_vm._v(_vm._s(item))])])
	  }))], 1)
	},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
	  return _c('div', {
	    staticStyle: {
	      height: "110px",
	      backgroundColor: "#D9141E",
	      justifyContent: "center",
	      paddingLeft: "30px",
	      paddingTop: "30px"
	    }
	  }, [_c('text', {
	    staticStyle: {
	      color: "#fff",
	      fontSize: "35px"
	    }
	  }, [_vm._v("朋友")])])
	}]}
	module.exports.render._withStripped = true

/***/ })

/******/ });